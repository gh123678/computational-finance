# CF2026 Project 2：波动率管理组合复现

Zhang Bowen · 12410604 · 2026-10-20

**先阅读 `report/Project2_Report.pdf`。** 本包包含论文核心结论的有限范围复现、P1绩效模块接入、原/新结果对照、公式修正留痕、单项敏感性、自主风险约束扩展和运行证据。使用真实公开数据，默认可离线重算，不需要账号或密钥。

## 结果与范围

选题：Moreira & Muir (2017), *Volatility-Managed Portfolios*, Journal of Finance 72(4), 1611-1644，DOI [10.1111/jofi.12513](https://doi.org/10.1111/jofi.12513)。目标为Table I Panel A的市场组合，并核对Table II夏普。

主复现1926-08至2015-04，1065个月：年化alpha **4.9535%**（原表4.86%），HC1标准误1.5683，beta0.60065，R²0.36078；超额夏普0.51588，市场0.41805。方向复现，非逐位数值复刻。精确月端点是与N一致的推断，未经作者确认。主方差是每日收益去均值后的平方和；初版平均平方的结果保留在`audit/variance_mean_initial/`。

自主扩展2016-2024：固定2015-04以前的c，2倍上限不重缩放，比较相同0/10/30bp单边费用。10bp下无上限/2倍上限最大回撤37.26%/23.00%，夏普0.501/0.615；CAGR9.128%/9.114%，市场14.288%。上限降低风险但未超过市场，夏普差bootstrap区间包含0。该窗口使用后取得的历史数据，不是当时提前封存的前向盲测。

## 运行

Python **3.10或以上**；本次实际测试环境为3.13，精确版本见`results/environment.json`。在解压后的项目根目录执行：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-tested.txt
python run_project.py --output reproduced_results
python scripts/independent_verify.py --results reproduced_results
python -m pytest tests p1_platform -q
```

如精确版本在当前Python不可安装，可使用`requirements.txt`的兼容范围；需要再次运行检查，不应直接假定与提交环境等价。报告和正式结果已经预生成，只阅读无需安装。

`python run_project.py`默认重建`results/`，建议用上面的`--output`保留提交证据。主入口校验全部原始ZIP的SHA；不联网，不更新数据。可选`python scripts/download_data.py`从官方来源获取快照，发现同名不同内容时拒绝覆盖；已冻结的manifest也拒绝覆盖。数据所有权归原来源，不包含任何私人金融账号数据。

复核正式提交结果与小样本：

```powershell
python scripts/independent_verify.py
python scripts/manual_checks.py
python scripts/verify_manifest.py
```

报告重建：

```powershell
python report/build_report.py
```

Windows优先使用系统仿宋/黑体字体并嵌入PDF。其他系统回退到ReportLab的STSong-Light；已交付PDF无需重建字体环境。报告内容依赖`results/`中的正式结果及核验记录。`run_all.ps1`可顺序重建正式结果、检查、手算和报告（Windows需要允许本地脚本执行）。

## 文件导航

| 位置 | 内容 |
|---|---|
| `report/Project2_Report.pdf` | 10页中文报告，可直接阅读 |
| `report/build_report.py` | 报告可编辑源文件，读取真实结果 |
| `docs/protocol.md` | 复现协议、补充假设、要求逐条映射 |
| `docs/paper_sources.md` | 原文完整引用、目标值核对及来源指纹 |
| `docs/p1_integration.md` | P1实际复用与本次新增边界 |
| `docs/demo.md` | 5分钟演示提纲和常见问题 |
| `sources/` | 课程任务原件、官方来源说明快照和引用 |
| `data/raw/` | 4份French官方ZIP，FIZ/CIZ各日/月频 |
| `data/source_manifest.json` | 获取时间、官方URL、字节数、SHA |
| `data/sample_daily_for_manual_check.csv` | 4个形成月的日收益手算样本 |
| `src/` | 严格数据适配、逆方差信号、回归与按月自融资执行 |
| `p1_platform/` | P1逐字节绩效模块与月度适配、来源版本/SHA |
| `results/comparison.csv` | 原表、本次值与差值并排 |
| `results/sensitivities.csv` | 方差定义、样本、来源与时点敏感性 |
| `results/holdout_*` | 全部11组后续账户及汇总 |
| `results/independent_verification.json` | 331项独立复算记录 |
| `results/manual_checks.*` | 核心公式显式手算及误差 |
| `results/figures/` | 可独立查看的研究图 |
| `results/tests.txt` | 实际21项检查输出 |
| `audit/variance_mean_initial/` | 公式修订前的配置、数值和月度证据 |
| `FILE_MANIFEST.json` | 最终文件SHA清单 |

## 方法边界

P1的`monthly_returns`实际参与每组收益重建对账，绩效逻辑适配为12期而非252期；P1原A股整手、T+1、涨跌停及容量规则没有冒充为美国因子执行规则。c在主样本中依原文使用事后等波动归一化，后续窗口冻结；超额收益用于夏普和回归，RF包含在净值/复利/回撤中。成本按月度持仓漂移后的成交额收取，期末不平仓；融资按RF，另列200bp借款利差。

本项目未获得作者原始2015数据快照和精确月端点。自然月实际交易日与原式22日的落实差异明确保留；未扫描端点或搜索最优上限来逼近目标。结果不能作为具体工具的实盘可行性或未来收益承诺。

本项目由AI协助实现、资料核对与报告整理；不宣称为未使用辅助工具的独立人工完成。提交前请阅读报告并确认课程对工具使用与署名的要求。
