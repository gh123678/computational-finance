# Project 1 的实际复用与本次新增

原仓库版本：`cb7e6a8c24b9ea8063fc6445aa990b540254b57e`。原平台文件未改。

1. `p1_platform/attribution.py`逐字节复制P1的`quant_research/attribution.py`。每次计算月度绩效时，P1的`monthly_returns(equity)`实际运行，将含初始1元基准的净值还原为月收益，与新引擎逐月收益比对。这不是只随包附带的闲置代码。
2. `p1_platform/performance.py`沿用P1`summarize`的净值、复利、峰值回撤和算术均值/样本标准差逻辑，明确改成每年12个月，且RF包含在总收益净值中；超额收益用于夏普和alpha。
3. `src/data.py`是P1数据边界的新增适配器：原P1字段面向A股行情、公司行动和可交易性；本次输入为美国市场研究因子的日/月超额收益及RF，保留严格日期、单位和缺失检查，不伪造A股K线。
4. `src/engine.py`增加上一月实现方差信号、逆方差权重、时序回归和按月自融资账户。本次因子是抽象研究组合；没有声称复用了P1整手、T+1、涨跌停、冲击容量和原始股数交易账本。

运行入口统一为`python run_project.py`。数据导入 -> 信号形成 -> 月度账户 -> P1绩效适配 -> 输出图表。配置保存在根目录`config.json`。复用与改写的来源SHA及版本在`p1_platform/provenance.json`。

边界：原Project1平台支持多因子A股选股，本题采用新的美国因子数据适配，实际共享的是绩效分析和严格数据边界约定。不是同一A股股票策略的样本外盈利验证。
