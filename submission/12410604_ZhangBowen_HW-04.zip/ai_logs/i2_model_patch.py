"""I2 model-proposed patch (unmodified text extracted from the first reply).

Provider: DeepSeek; model: deepseek-v4-pro. This is the model's proposal, not
the final repaired routine. Kept separate from code/ai_debug_exercise.py.
"""
import numpy as np
from scipy.special import ndtr

def candidate_pricer(spot=100.0, strike=105.0, rate=0.05,
                     volatility=0.20, tau=1.0, mu=0.12):
    # Input validation
    params = [spot, strike, rate, volatility, tau]
    if any(not np.isfinite(p) for p in params):
        raise ValueError("All inputs must be finite.")
    if spot < 0 or strike < 0 or volatility < 0 or tau < 0:
        raise ValueError("spot, strike, volatility, tau must be non-negative.")
    if strike == 0:
        raise ValueError("strike must be positive.")
    # mu is accepted but not used; no need to validate beyond finite

    # Boundary cases
    if tau == 0:
        # At expiry, payoff is deterministic
        call = max(spot - strike, 0.0)
        put = max(strike - spot, 0.0)
        return {'call': call, 'put': put}

    if spot == 0:
        # Spot is zero: call worthless, put = discounted strike
        discount = np.exp(-rate * tau)
        call = 0.0
        put = strike * discount
        return {'call': call, 'put': put}

    if volatility == 0:
        # No randomness: forward price is spot * exp(rate * tau)
        forward = spot * np.exp(rate * tau)
        discount = np.exp(-rate * tau)
        call = max(forward - strike, 0.0) * discount
        put = max(strike - forward, 0.0) * discount
        return {'call': call, 'put': put}

    # Normal case
    scale = volatility * np.sqrt(tau)
    d1 = (np.log(spot / strike) + (rate + 0.5 * volatility**2) * tau) / scale
    d2 = d1 - scale
    discount = np.exp(-rate * tau)

    call = spot * ndtr(d1) - strike * discount * ndtr(d2)
    put = strike * discount * ndtr(-d2) - spot * ndtr(-d1)

    return {'call': float(call), 'put': float(put)}
