# MA216 Computational Finance — Homework 4

Zhang Bowen, student ID 12410604. Submitted 21 October 2026.

## Contents

| Path | Contents |
|---|---|
| `12410604_ZhangBowen_HW-04.pdf` | main report: T1–T8, A1–A3, I1–I2, AI declaration, appendix |
| `reading/reading_notes.pdf` | R1 reading notes (5 pages): Kwok (2008) and Glasserman (2003) |
| `report/` | LaTeX sources for the main report |
| `reading/reading_notes.tex` | LaTeX source for the reading notes |
| `code/` | implementations, tests, experiment drivers, I1/I2 check scripts |
| `notebook/CF2026_HW04_completed.ipynb` | executed notebook (all outputs present, 0 errors) |
| `notebook/CF2026_HW04_scaffold.ipynb` | supplied scaffold, unchanged |
| `results/` | CSV/JSON/NPZ outputs and saved diagnostic text |
| `figures/` | all PNG and PDF figures used in the report |
| `ai_logs/` | full I1/I2 transcripts, session JSON, model patch |

## Environment

Python 3.13.9, NumPy 2.4.6, SciPy 1.16.3, Matplotlib 3.10.6, pandas 2.3.3,
pytest 8.3.0, nbformat 5.10.4, nbconvert 7.16.6, MiKTeX 25.12 on Windows 11.
Random generator: `numpy.random.default_rng` (PCG64).

## Reproduction

```bash
python code/run_experiments.py      # all A1-A3 CSV and figures
python code/check_i1_claims.py      # I1 independent checks (14/14)
python code/check_i2_patch.py       # model patch checks (17/18; mu=NaN is the documented failure)
python code/i2_before_after.py      # I2 before/after diagnostics
python -m pytest -q code            # full suite, 73 passed
cd report   && pdflatex main.tex && pdflatex main.tex
cd reading  && pdflatex reading_notes.tex && pdflatex reading_notes.tex
```

To rebuild and execute the notebook:

```bash
python code/build_notebook.py
python -m jupyter nbconvert --to notebook --execute --inplace \
    notebook/CF2026_HW04_completed.ipynb
```

## Seeds

Main stream 4102026; A1 path B 4102027; A2 paths 4102028; A2 coupled grids
4102029; A3 Monte Carlo 4102030–4102032; I1 independent checks 20261021
(20261022 for the Euler contrast). Also recorded in `results/run_metadata.json`.

## AI-use summary

I1 audited four claims with `deepseek-v4-pro` and `deepseek-flash` through the
Anthropic-compatible endpoint on 21 October 2026 (text only, reasoning blocks
disabled, no tools). Both shared one provider; a second provider (local Codex
CLI) was attempted and its endpoint was unreachable. Full prompts and replies
are in `ai_logs/`. Every model-supplied number and identity was recomputed by
`code/check_i1_claims.py`; Model B's counterexample to claim (d) fails parity
by 99.758 and is reported as rejected evidence despite a correct verdict.
I2 used `deepseek-v4-pro` for a three-exchange repair of
`code/ai_debug_exercise.py`; the model's patch is preserved unchanged in
`ai_logs/i2_model_patch.py`. An AI coding assistant (Claude Code; environment
identifier `deepseek-flash`) helped implement routines, run tests, and draft
LaTeX; all reported numbers come from the scripts and tests above.

## Fixed hashes (SHA-256)

- `code/ai_debug_exercise.py` (original, unchanged):
  `0ef9e91e936fa45165d46c97e8b313b6eaeafcf7d1a0d82ef2ef764a8dadb99f`
- `code/i2_final_repair.py` (final repair):
  `0acee06a9c6e6cfac0ee79a188d70dd8b68e85e835f73a52a343db662208ef65`
- `code/check_i1_claims.py` (independent checks):
  `d4f3fb9307c001407aec71b44394615d5994d6f17c8c3a2e81e156ad7623f06f`
