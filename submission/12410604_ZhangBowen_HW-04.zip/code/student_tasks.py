"""HW-04 student implementations.

Array convention: the last axis is time and every path includes the initial
value.  All randomness is supplied through an explicit numpy.random.Generator.
"""
from __future__ import annotations

import math
from typing import Callable, Sequence

import numpy as np
from scipy.special import ndtr


def _finite_scalar(name: str, value: float) -> float:
    try:
        array = np.asarray(value, dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a real number") from exc
    if array.ndim != 0 or not np.isfinite(array):
        raise ValueError(f"{name} must be a finite real scalar")
    return float(array)


def _validate_gbm(s0: float, mu: float, sigma: float, h: float) -> tuple[float, float, float, float]:
    s0 = _finite_scalar("s0", s0)
    mu = _finite_scalar("mu", mu)
    sigma = _finite_scalar("sigma", sigma)
    h = _finite_scalar("h", h)
    if s0 <= 0.0:
        raise ValueError("s0 must be strictly positive")
    if sigma < 0.0:
        raise ValueError("sigma must be non-negative")
    if h <= 0.0:
        raise ValueError("h must be strictly positive")
    return s0, mu, sigma, h


def gbm_from_increments(s0: float, mu: float, sigma: float, h: float,
                        dw: np.ndarray) -> np.ndarray:
    """Map supplied Brownian increments on one grid to exact GBM grid prices.

    ``dw`` has shape (..., L); the returned array has shape (..., L + 1) and
    includes ``s0``.  The transition is
    ``S_{i+1} = S_i exp((mu - sigma^2/2) h + sigma dw_i)``.
    """
    s0, mu, sigma, h = _validate_gbm(s0, mu, sigma, h)
    increments = np.asarray(dw, dtype=float)
    if increments.ndim < 1 or increments.size == 0:
        raise ValueError("dw must be a non-empty array with a time axis")
    if not np.all(np.isfinite(increments)):
        raise ValueError("dw must contain only finite values")
    drift = (mu - 0.5 * sigma ** 2) * h
    log_steps = drift + sigma * increments
    log_paths = np.cumsum(log_steps, axis=-1)
    log_paths = np.concatenate(
        [np.zeros(log_paths.shape[:-1] + (1,)), log_paths], axis=-1)
    return s0 * np.exp(log_paths)


def simulate_gbm(s0: float, mu: float, sigma: float, T: float,
                 steps: int, paths: int, rng: np.random.Generator):
    """Simulate exact GBM grid values.

    Returns ``(times, prices, dw)`` with shapes ``(L + 1,)``, ``(M, L + 1)``
    and ``(M, L)`` where ``dw`` are the Gaussian Brownian increments.
    """
    s0, mu, sigma, h = _validate_gbm(s0, mu, sigma, 1.0)
    T = _finite_scalar("T", T)
    if T <= 0.0:
        raise ValueError("T must be strictly positive")
    if not isinstance(steps, (int, np.integer)) or isinstance(steps, bool):
        raise ValueError("steps must be a positive integer")
    if not isinstance(paths, (int, np.integer)) or isinstance(paths, bool):
        raise ValueError("paths must be a positive integer")
    steps = int(steps)
    paths = int(paths)
    if steps <= 0 or paths <= 0:
        raise ValueError("steps and paths must be positive")
    if not isinstance(rng, np.random.Generator):
        raise TypeError("rng must be a numpy.random.Generator")
    h = T / steps
    dw = rng.normal(0.0, math.sqrt(h), size=(paths, steps))
    prices = gbm_from_increments(s0, mu, sigma, h, dw)
    times = np.linspace(0.0, T, steps + 1)
    return times, prices, dw


def realized_variation(prices: np.ndarray, kind: str = 'simple') -> np.ndarray:
    """Running sum of squared simple or log returns, initial zero included."""
    values = np.asarray(prices, dtype=float)
    if values.ndim < 1 or values.shape[-1] < 2:
        raise ValueError("prices must have a time axis of length at least 2")
    if not np.all(np.isfinite(values)) or np.any(values <= 0.0):
        raise ValueError("prices must be finite and strictly positive")
    if kind == 'simple':
        returns = np.diff(values, axis=-1) / values[..., :-1]
    elif kind == 'log':
        returns = np.diff(np.log(values), axis=-1)
    else:
        raise ValueError("kind must be 'simple' or 'log'")
    running = np.cumsum(returns ** 2, axis=-1)
    zero = np.zeros(running.shape[:-1] + (1,))
    return np.concatenate([zero, running], axis=-1)


def squared_return_moments(mu: float, sigma: float, h: float,
                           kind: str = 'euler') -> tuple[float, float]:
    """Return ``(E[R^2], Var(R^2))`` for one grid increment.

    ``euler`` and ``log`` are the supplied Gaussian returns; ``exact_simple``
    uses the fourth moment of exp(X) - 1 and is the optional enrichment.
    """
    mu = _finite_scalar("mu", mu)
    sigma = _finite_scalar("sigma", sigma)
    h = _finite_scalar("h", h)
    if sigma < 0.0 or h <= 0.0:
        raise ValueError("sigma must be non-negative and h positive")
    s2 = sigma ** 2
    if kind in ('euler', 'log'):
        mean = mu if kind == 'euler' else mu - 0.5 * s2
        mean_sq = mean ** 2 * h ** 2 + s2 * h
        var = 2.0 * s2 ** 2 * h ** 2 + 4.0 * mean ** 2 * s2 * h ** 3
        return float(mean_sq), float(var)
    if kind == 'exact_simple':
        m = (mu - 0.5 * s2) * h
        v = s2 * h
        e2 = math.exp(2.0 * m + 2.0 * v) - 2.0 * math.exp(m + 0.5 * v) + 1.0
        e4 = (math.exp(4.0 * m + 8.0 * v)
              - 4.0 * math.exp(3.0 * m + 4.5 * v)
              + 6.0 * math.exp(2.0 * m + 2.0 * v)
              - 4.0 * math.exp(m + 0.5 * v) + 1.0)
        return float(e2), float(e4 - e2 ** 2)
    raise ValueError("kind must be 'euler', 'log', or 'exact_simple'")


def coupled_variation(mu: float, sigma: float, T: float, levels: Sequence[int],
                      paths: int, rng: np.random.Generator,
                      batch: int = 250) -> dict[str, np.ndarray]:
    """Terminal squared-return sums on nested grids sharing one Brownian path.

    Coarse increments are block sums of the finest increments, never averages
    and never fresh draws.  Returns arrays of shape ``(len(levels), paths)``.
    """
    mu = _finite_scalar("mu", mu)
    sigma = _finite_scalar("sigma", sigma)
    T = _finite_scalar("T", T)
    if sigma < 0.0 or T <= 0.0:
        raise ValueError("sigma must be non-negative and T positive")
    if not isinstance(paths, (int, np.integer)) or isinstance(paths, bool) or paths <= 0:
        raise ValueError("paths must be a positive integer")
    if not isinstance(batch, (int, np.integer)) or isinstance(batch, bool) or batch <= 0:
        raise ValueError("batch must be a positive integer")
    if not isinstance(rng, np.random.Generator):
        raise TypeError("rng must be a numpy.random.Generator")
    levels = [int(level) if isinstance(level, (int, np.integer)) and not isinstance(level, bool)
              else None for level in levels]
    if not levels or any(level is None or level <= 0 for level in levels):
        raise ValueError("levels must be a non-empty sequence of positive integers")
    finest = max(levels)
    if any(finest % level != 0 for level in levels):
        raise ValueError("every level must divide the finest level")
    blocks = [finest // level for level in levels]
    paths = int(paths)
    batch = int(batch)
    h_fine = T / finest
    out = {name: np.empty((len(levels), paths)) for name in ('simple', 'euler', 'log')}
    done = 0
    while done < paths:
        size = min(batch, paths - done)
        dw_fine = rng.normal(0.0, math.sqrt(h_fine), size=(size, finest))
        for j, (level, block) in enumerate(zip(levels, blocks)):
            if block == 1:
                dw_coarse = dw_fine
            else:
                dw_coarse = dw_fine.reshape(size, level, block).sum(axis=2)
            h = T / level
            prices = gbm_from_increments(1.0, mu, sigma, h, dw_coarse)
            simple = (np.expm1((mu - 0.5 * sigma ** 2) * h + sigma * dw_coarse)) ** 2
            euler = (mu * h + sigma * dw_coarse) ** 2
            logs = ((mu - 0.5 * sigma ** 2) * h + sigma * dw_coarse) ** 2
            out['simple'][j, done:done + size] = simple.sum(axis=1)
            out['euler'][j, done:done + size] = euler.sum(axis=1)
            out['log'][j, done:done + size] = logs.sum(axis=1)
        done += size
    return out


def _validate_bs(spot, strike: float, rate: float, volatility: float, tau):
    strike = _finite_scalar("strike", strike)
    rate = _finite_scalar("rate", rate)
    volatility = _finite_scalar("volatility", volatility)
    if strike <= 0.0:
        raise ValueError("strike must be strictly positive")
    if volatility < 0.0:
        raise ValueError("volatility must be non-negative")
    try:
        S = np.asarray(spot, dtype=float)
        t = np.asarray(tau, dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError("spot and tau must be real arrays") from exc
    if not np.all(np.isfinite(S)) or not np.all(np.isfinite(t)):
        raise ValueError("spot and tau must be finite")
    if np.any(S < 0.0) or np.any(t < 0.0):
        raise ValueError("spot and tau must be non-negative")
    S, t = np.broadcast_arrays(S, t)
    return S, t, strike, rate, volatility


def bs_d(spot: float | np.ndarray, strike: float, rate: float,
         volatility: float, tau: float) -> tuple[np.ndarray, np.ndarray]:
    """Standard normal arguments for nondegenerate positive inputs."""
    S, t, strike, rate, volatility = _validate_bs(spot, strike, rate, volatility, tau)
    if np.any(S <= 0.0):
        raise ValueError("spot must be strictly positive for the normal arguments")
    if volatility == 0.0:
        raise ValueError("volatility must be strictly positive for the normal arguments")
    if np.any(t <= 0.0):
        raise ValueError("tau must be strictly positive for the normal arguments")
    scale = volatility * np.sqrt(t)
    d1 = (np.log(S / strike) + (rate + 0.5 * volatility ** 2) * t) / scale
    return d1, d1 - scale


def bs_prices(spot: float | np.ndarray, strike: float, rate: float,
              volatility: float, tau: float) -> tuple[np.ndarray, np.ndarray]:
    """European call and put values with explicit valid degenerate branches."""
    S, t, strike, rate, volatility = _validate_bs(spot, strike, rate, volatility, tau)
    discount = np.exp(-rate * t)
    intrinsic_call = np.maximum(S - strike, 0.0)
    intrinsic_put = np.maximum(strike - S, 0.0)
    forward_call = np.maximum(S - strike * discount, 0.0)
    forward_put = np.maximum(strike * discount - S, 0.0)

    normal = (t > 0.0) & (volatility > 0.0) & (S > 0.0)
    safe_t = np.where(normal, t, 1.0)
    safe_S = np.where(normal, S, 1.0)
    scale = np.where(normal, volatility * np.sqrt(safe_t), 1.0)
    d1 = (np.log(safe_S / strike) + (rate + 0.5 * volatility ** 2) * safe_t) / scale
    d2 = d1 - scale
    call_n = S * ndtr(d1) - strike * discount * ndtr(d2)
    put_n = strike * discount * ndtr(-d2) - S * ndtr(-d1)

    call = np.where(normal, call_n, np.where(t > 0.0, forward_call, intrinsic_call))
    put = np.where(normal, put_n, np.where(t > 0.0, forward_put, intrinsic_put))
    return call, put


def call_pde_residual(spot: float, strike: float, rate: float, volatility: float,
                      tau: float, hs: float, ht: float,
                      pricer: Callable = bs_prices) -> float:
    """Central-difference residual of the Black-Scholes PDE at interior points.

    Calendar time decreases as tau grows, so the time derivative is ``-C_tau``.
    """
    spot = _finite_scalar("spot", spot)
    tau = _finite_scalar("tau", tau)
    hs = _finite_scalar("hs", hs)
    ht = _finite_scalar("ht", ht)
    if hs <= 0.0 or ht <= 0.0:
        raise ValueError("hs and ht must be strictly positive")
    if spot - hs <= 0.0:
        raise ValueError("spot - hs must be strictly positive")
    if tau - ht <= 0.0:
        raise ValueError("tau - ht must be strictly positive")
    S = spot

    def call(s: float, t: float) -> float:
        value, _ = pricer(s, strike, rate, volatility, t)
        return float(np.asarray(value))

    c = call(S, tau)
    c_up = call(S + hs, tau)
    c_dn = call(S - hs, tau)
    c_forward = call(S, tau + ht)
    c_back = call(S, tau - ht)
    c_s = (c_up - c_dn) / (2.0 * hs)
    c_ss = (c_up - 2.0 * c + c_dn) / hs ** 2
    c_tau = (c_forward - c_back) / (2.0 * ht)
    return float(-c_tau + 0.5 * volatility ** 2 * S ** 2 * c_ss
                 + rate * S * c_s - rate * c)


def discounted_payoffs(spot: float, strike: float, rate: float,
                       volatility: float, tau: float, normals: np.ndarray):
    """Exact risk-neutral terminal sample and discounted call/put payoffs."""
    spot = _finite_scalar("spot", spot)
    strike = _finite_scalar("strike", strike)
    rate = _finite_scalar("rate", rate)
    volatility = _finite_scalar("volatility", volatility)
    tau = _finite_scalar("tau", tau)
    if spot <= 0.0 or strike <= 0.0:
        raise ValueError("spot and strike must be strictly positive")
    if volatility < 0.0 or tau <= 0.0:
        raise ValueError("volatility must be non-negative and tau positive")
    Z = np.asarray(normals, dtype=float)
    if Z.size == 0 or not np.all(np.isfinite(Z)):
        raise ValueError("normals must be a non-empty finite array")
    terminal = spot * np.exp((rate - 0.5 * volatility ** 2) * tau
                             + volatility * math.sqrt(tau) * Z)
    discount = math.exp(-rate * tau)
    call = discount * np.maximum(terminal - strike, 0.0)
    put = discount * np.maximum(strike - terminal, 0.0)
    return terminal, call, put


def estimate(values: np.ndarray) -> dict[str, float]:
    """Monte Carlo mean, standard error (ddof=1) and 95% normal interval."""
    x = np.asarray(values, dtype=float)
    if x.ndim != 1 or x.size < 2:
        raise ValueError("values must be a one-dimensional array with n >= 2")
    if not np.all(np.isfinite(x)):
        raise ValueError("values must be finite")
    n = x.size
    mean = float(x.mean())
    sd = float(x.std(ddof=1))
    se = sd / math.sqrt(n)
    return {"estimate": mean, "se": se, "low": mean - 1.959963984540054 * se,
            "high": mean + 1.959963984540054 * se, "n": int(n)}
