"""Run the same I2 checks against the unchanged original and the final repair.

Run: python code/i2_before_after.py
Writes results/i2_before_after.txt.
"""
from __future__ import annotations

import math
import warnings
from pathlib import Path

import numpy as np

from ai_debug_exercise import candidate_pricer as original
from i2_final_repair import repaired_pricer as final

ROOT = Path(__file__).resolve().parent.parent
C, P = 8.021352235143176, 7.9004418077181455
S, E, r, tau = 100.0, 105.0, 0.05, 1.0
discount = math.exp(-r * tau)


def call(fn, **kwargs):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            out = fn(**kwargs)
        if not isinstance(out, dict):
            return f"returned {out!r}"
        return f"call={out['call']:.10f}, put={out['put']:.10f}"
    except Exception as exc:  # noqa: BLE001 - diagnostic report
        return f"raised {type(exc).__name__}: {exc}"


def rejects(fn, **kwargs) -> bool:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            fn(**kwargs)
    except (ValueError, TypeError):
        return True
    except Exception:
        return False
    return False


def suite(fn) -> list[str]:
    lines = []

    base = fn()
    lines.append(f"default :: {call(fn)}; benchmark error = "
                 f"{base['call'] - C:+.10f} (call), {base['put'] - P:+.10f} (put)")
    lines.append(f"parity :: residual = {base['call'] - base['put'] - (S - E * discount):+.10f}")
    lines.append(f"bounds :: call in [max(S-Ee^-rT,0), S] = "
                 f"{max(S - E * discount, 0.0):.6f} <= {base['call']:.6f} <= {S:.6f}; "
                 f"put in [max(Ee^-rT-S,0), Ee^-rT] = "
                 f"{max(E * discount - S, 0.0):.6f} <= {base['put']:.6f} <= {E * discount:.6f}")
    lines.append(f"expiry tau=0 :: {call(fn, tau=0.0)} (expected call=0.0, put=5.0)")
    lines.append(f"zero spot :: {call(fn, spot=0.0)} "
                 f"(expected call=0.0, put={E*discount:.10f})")
    lines.append(f"zero volatility :: {call(fn, volatility=0.0)} "
                 f"(expected call={max(S-E*discount,0):.10f}, put=0.0)")
    for label, kwargs in (
            ("negative spot", dict(spot=-1.0)),
            ("zero strike", dict(strike=0.0)),
            ("negative volatility", dict(volatility=-0.1)),
            ("negative tau", dict(tau=-0.1)),
            ("NaN spot", dict(spot=float("nan"))),
            ("infinite rate", dict(rate=float("inf"))),
            ("nonnumeric spot", dict(spot="x")),
            ("NaN mu", dict(mu=float("nan")))):
        lines.append(f"rejects {label} :: {'yes' if rejects(fn, **kwargs) else 'NO'}")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            same = (fn(mu=0.12) == fn(mu=0.5) == fn(mu=-0.3))
        lines.append(f"drift invariance :: {'yes' if same else 'NO'}")
    except Exception as exc:
        lines.append(f"drift invariance :: raised {type(exc).__name__}: {exc}")
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        try:
            fn(tau=0.0)
            fn(spot=0.0)
            fn(volatility=0.0)
            lines.append("warnings on degenerate branches :: none")
        except Warning as exc:
            lines.append(f"warnings on degenerate branches :: {type(exc).__name__}: {exc}")
    return lines


out = ["I2 before/after diagnostic", "=" * 27, "",
       "UNCHANGED ORIGINAL (code/ai_debug_exercise.py)", "-" * 44]
out += suite(original)
out += ["", "FINAL REPAIR (code/i2_final_repair.py)", "-" * 40]
out += suite(final)
text = "\n".join(out) + "\n"
(ROOT / "results" / "i2_before_after.txt").write_text(text, encoding="utf-8")
print(text, end="")
