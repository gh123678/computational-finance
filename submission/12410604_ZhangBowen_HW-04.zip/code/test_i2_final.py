"""Acceptance tests for the final I2 repair."""
from __future__ import annotations

import math

import numpy as np
import pytest
from scipy.special import ndtr

from i2_final_repair import repaired_pricer


def test_benchmark():
    values = repaired_pricer()
    assert values["call"] == pytest.approx(8.021352235143176, abs=1e-12)
    assert values["put"] == pytest.approx(7.9004418077181455, abs=1e-12)


def test_parity_and_bounds():
    E, r = 105.0, 0.05
    for S in (0.0, 50.0, 100.0, 105.0, 150.0, 200.0):
        for tau in (0.0, 0.25, 1.0):
            call, put = repaired_pricer(S, E, r, 0.2, tau).values()
            discount = math.exp(-r * tau)
            assert call - put == pytest.approx(S - E * discount, abs=1e-10)
            assert max(S - E * discount, 0.0) - 1e-12 <= call <= S + 1e-12
            assert max(E * discount - S, 0.0) - 1e-12 <= put <= E * discount + 1e-12


def test_expiry():
    assert repaired_pricer(tau=0.0) == {"call": 0.0, "put": 5.0}


def test_zero_spot():
    values = repaired_pricer(spot=0.0)
    assert values["call"] == 0.0
    assert values["put"] == pytest.approx(105.0 * math.exp(-0.05))


def test_zero_volatility():
    values = repaired_pricer(volatility=0.0)
    assert values["call"] == pytest.approx(0.12091042742503078)
    assert values["put"] == 0.0


def test_mu_is_validated_but_unused():
    assert repaired_pricer(mu=-0.3) == repaired_pricer(mu=0.12) == repaired_pricer(mu=2.0)
    with pytest.raises(ValueError):
        repaired_pricer(mu=float("nan"))
    with pytest.raises(ValueError):
        repaired_pricer(mu=float("inf"))


@pytest.mark.parametrize("kwargs", [
    {"spot": -1.0}, {"strike": 0.0}, {"volatility": -0.1}, {"tau": -0.1},
    {"spot": float("nan")}, {"rate": float("inf")},
])
def test_invalid_values(kwargs):
    with pytest.raises(ValueError):
        repaired_pricer(**kwargs)


@pytest.mark.parametrize("kwargs", [{"spot": "x"}, {"tau": True},
                                    {"strike": [100.0]}])
def test_non_scalar_inputs(kwargs):
    with pytest.raises(TypeError):
        repaired_pricer(**kwargs)


def test_no_warnings_on_degenerate_branches():
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        repaired_pricer(tau=0.0)
        repaired_pricer(spot=0.0)
        repaired_pricer(volatility=0.0)


def test_finite_outputs():
    values = repaired_pricer()
    assert all(np.isfinite(value) for value in values.values())


def test_normal_arguments_and_discount():
    for spot, strike, rate, vol, tau in (
            (100.0, 105.0, 0.05, 0.20, 1.0),
            (120.0, 90.0, 0.10, 0.30, 0.5)):
        scale = vol * math.sqrt(tau)
        d1 = (math.log(spot / strike) + (rate + 0.5 * vol**2) * tau) / scale
        d2 = d1 - scale
        expected = spot * ndtr(d1) - strike * math.exp(-rate * tau) * ndtr(d2)
        assert repaired_pricer(spot, strike, rate, vol, tau)["call"] == \
            pytest.approx(expected, abs=1e-12)
