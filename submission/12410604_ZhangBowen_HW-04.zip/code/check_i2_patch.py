"""Independent checks of the model-proposed I2 patch.

Run: python code/check_i2_patch.py
"""
from __future__ import annotations

import importlib.util
import math
import warnings
from pathlib import Path

import numpy as np

PATCH = Path(__file__).resolve().parent.parent / "ai_logs" / "i2_model_patch.py"
spec = importlib.util.spec_from_file_location("i2_model_patch", PATCH)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
pricer = module.candidate_pricer

results: list[tuple[str, bool, str]] = []


def record(name: str, passed: bool, detail: str = "") -> None:
    results.append((name, bool(passed), detail))


def rejects(exception: type[BaseException], **kwargs) -> bool:
    try:
        pricer(**kwargs)
    except exception:
        return True
    except Exception:
        return False
    return False


S, E, r, sigma, tau = 100.0, 105.0, 0.05, 0.20, 1.0
C, P = 8.021352235143176, 7.9004418077181455
base = pricer()
record("C1 benchmark call = 8.0213522351", abs(base["call"] - C) < 1e-8,
       f"{base['call']:.10f}")
record("C1 benchmark put = 7.9004418077", abs(base["put"] - P) < 1e-8,
       f"{base['put']:.10f}")

discount = math.exp(-r * tau)
parity = base["call"] - base["put"] - (S - E * discount)
record("C2 parity at default", abs(parity) < 1e-10, f"residual {parity:.3e}")

bounds_ok = True
for spot in (0.0, 25.0, 100.0, 105.0, 200.0):
    for t in (0.0, 0.25, 1.0):
        c, p = pricer(spot=spot, tau=t)["call"], pricer(spot=spot, tau=t)["put"]
        d = math.exp(-r * t)
        bounds_ok &= (c >= max(spot - E * d, 0.0) - 1e-10 and c <= spot + 1e-10
                      and p >= max(E * d - spot, 0.0) - 1e-10
                      and p <= E * d + 1e-10)
record("C2 no-arbitrage bounds on 15 points", bounds_ok)

record("C3 expiry intrinsic", pricer(tau=0.0) == {"call": 0.0, "put": 5.0},
       str(pricer(tau=0.0)))
record("C3 zero spot put = E exp(-r tau)",
       abs(pricer(spot=0.0)["put"] - E * discount) < 1e-10,
       f"{pricer(spot=0.0)['put']:.10f}")
record("C3 zero volatility call = discounted intrinsic",
       abs(pricer(volatility=0.0)["call"] - max(S - E * discount, 0.0)) < 1e-10,
       f"{pricer(volatility=0.0)['call']:.10f}")

for label, kwargs in (
        ("negative spot", dict(spot=-1.0)),
        ("zero strike", dict(strike=0.0)),
        ("negative volatility", dict(volatility=-1.0)),
        ("negative tau", dict(tau=-1.0)),
        ("NaN spot", dict(spot=float("nan"))),
        ("infinite rate", dict(rate=float("inf"))),
        ("nonnumeric spot", dict(spot="x")),
        ("NaN mu", dict(mu=float("nan")))):
    ok = rejects((ValueError, TypeError), **kwargs)
    record(f"C3 rejects {label}", ok,
           "raised" if ok else "accepted or wrong exception")

record("physical drift mu is not used",
       pricer(mu=0.12) == pricer(mu=0.5) == pricer(mu=-0.3))

with warnings.catch_warnings():
    warnings.simplefilter("error")
    try:
        pricer(tau=0.0)
        pricer(spot=0.0)
        pricer(volatility=0.0)
        clean = True
        detail = "no warnings"
    except Warning as exc:
        clean = False
        detail = f"{type(exc).__name__}: {exc}"
record("C3 degenerate branches emit no warnings", clean, detail)

finite = all(math.isfinite(v) for v in base.values())
record("prices finite at default", finite)

passed = sum(1 for _, ok, _ in results if ok)
print(f"I2 model patch checks: {passed}/{len(results)} passed")
for name, ok, detail in results:
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" :: {detail}" if detail else ""))
Path(__file__).resolve().parent.parent.joinpath("results", "i2_patch_checks.txt").write_text(
    "\n".join([f"I2 model patch checks: {passed}/{len(results)} passed"]
              + [f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" :: {detail}" if detail else "")
                 for name, ok, detail in results]) + "\n", encoding="utf-8")
