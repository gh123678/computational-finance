"""Build the completed HW-04 notebook from the supplied scaffold.

The original scaffold is read from the course directory; the implementation
cell embeds ``student_tasks.py`` verbatim so the notebook is self-contained.
"""
from __future__ import annotations

from pathlib import Path

import nbformat as nbf

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SCAFFOLD = Path(r"C:\Users\Admin\Desktop\计算金融\CF2026_HW04.ipynb")
TARGET = ROOT / "notebook" / "CF2026_HW04_completed.ipynb"

impl = (HERE / "student_tasks.py").read_text(encoding="utf-8")
impl = impl.replace("from __future__ import annotations\n\n", "")
impl = impl.replace(
    '"""HW-04 student implementations.\n\nArray convention: the last axis is time and every path includes the initial\nvalue.  All randomness is supplied through an explicit numpy.random.Generator.\n"""',
    '"""HW-04 student implementations (completed).\n\nArray convention: the last axis is time and every path includes the initial\nvalue. All randomness is supplied through an explicit numpy.random.Generator.\n"""')

setup = '''import sys
import numpy as np
import scipy
import matplotlib
from scipy.special import ndtr

print("Python", sys.version.split()[0])
print("NumPy", np.__version__, "SciPy", scipy.__version__,
      "Matplotlib", matplotlib.__version__)
print("Versions above are the actually executed environment; no installation "
      "is performed by this notebook.")'''

a1 = r'''import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

%matplotlib inline

RESULTS = Path.cwd().parent / "results" / "notebook"
RESULTS.mkdir(parents=True, exist_ok=True)

rng = np.random.default_rng(4102026)
times, prices, dw = simulate_gbm(100.0, 0.05, 0.20, 2.0, 500, 1, rng)
path = prices[0]
pd.DataFrame({"time": times, "price": path}).to_csv(
    RESULTS / "a1_path_L500.csv", index=False)

fig, ax = plt.subplots(figsize=(6.4, 3.6))
ax.plot(times, path, lw=1.0)
ax.set(xlabel="time t (years)", ylabel="stock price S(t)",
       title="A1(a) exact GBM: S0=100, mu=0.05, sigma=0.20, T=2, L=500")
plt.show()

rng_b = np.random.default_rng(4102027)
times_b, prices_b, dw_b = simulate_gbm(1.0, 0.05, 0.30, 1.0, 10000, 1, rng_b)
path_b = prices_b[0]
pd.DataFrame({"time": times_b, "price": path_b}).to_csv(
    RESULTS / "a1_path_L10000.csv", index=False)

for upper, label in ((1.0, "[0, 1]"), (0.1, "[0, 0.1]"), (0.01, "[0, 0.01]")):
    mask = times_b <= upper + 1e-15
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    ax.plot(times_b[mask], path_b[mask], lw=1.1, color="C1")
    ax.set(xlabel="time t (years)", ylabel="stock price S(t)",
           title=f"A1(b) same saved path on {label}, L=10^4")
    plt.show()

log_increments = (0.05 - 0.5 * 0.30 ** 2) * (1.0 / 10000) + 0.30 * dw_b[0]
zero_vol = gbm_from_increments(1.0, 0.05, 0.0, 0.1, np.zeros(5))
checks = {
    "A1(a) shape (L+1,)": path.shape == (501,),
    "A1(b) shape (L+1,)": path_b.shape == (10001,),
    "initial values exact": bool(path[0] == 100.0 and path_b[0] == 1.0),
    "all prices positive": bool(np.all(path > 0) and np.all(path_b > 0)),
    "sigma=0 deterministic max error": float(np.max(np.abs(
        zero_vol - np.exp(0.05 * 0.1 * np.arange(6))))),
    "terminal log identity error": float(abs(
        math.log(path_b[-1] / path_b[0]) - log_increments.sum())),
}
bad_parameters = 0
for bad in ((0.0, 0.05, 0.2, 0.1), (1.0, 0.05, -0.2, 0.1),
            (1.0, 0.05, 0.2, 0.0), (1.0, float("nan"), 0.2, 0.1)):
    try:
        gbm_from_increments(*bad, np.zeros(3))
    except ValueError:
        bad_parameters += 1
checks["invalid parameter cases rejected"] = f"{bad_parameters}/4"
print(checks)'''

a2 = r'''import math
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

S0, mu, sigma, T = 1.0, 0.05, 0.30, 0.5
sigma2T = sigma ** 2 * T

rng = np.random.default_rng(4102028)
times, prices, _ = simulate_gbm(S0, mu, sigma, T, 100, 10, rng)
running = realized_variation(prices, "simple")
pd.DataFrame(np.column_stack([times, running.T])).to_csv(
    RESULTS / "a2_running_sums.csv", index=False, header=False)

fig, ax = plt.subplots(figsize=(6.4, 3.8))
for j in range(10):
    ax.plot(times, running[j], lw=0.8, alpha=0.75)
ax.plot(times, sigma ** 2 * times, color="black", lw=2.0,
        label=r"$\sigma^2 t$ (continuous limit)")
ax.set(xlabel="time t (years)", ylabel="running sum of squared simple returns",
       title="A2(a) ten exact paths, L=100, h=0.005")
ax.legend()
plt.show()

levels = [25, 50, 100, 200, 400]
M = 5000
coupled = coupled_variation(mu, sigma, T, levels, M,
                            np.random.default_rng(4102029), batch=250)
rows = []
for kind in ("simple", "euler", "log"):
    theory_kind = "exact_simple" if kind == "simple" else kind
    for j, L in enumerate(levels):
        values = coupled[kind][j]
        h = T / L
        e2, v2 = squared_return_moments(mu, sigma, h, theory_kind)
        mean = float(values.mean())
        rows.append({
            "method": kind, "L": L, "h": h,
            "mean": mean, "variance": float(values.var(ddof=1)),
            "bias": mean - sigma2T,
            "rmse": float(np.sqrt(np.mean((values - sigma2T) ** 2))),
            "se_mean": float(values.std(ddof=1) / math.sqrt(M)),
            "theory_mean": L * e2, "theory_variance": L * v2,
        })
summary = pd.DataFrame(rows)
summary.to_csv(RESULTS / "a2_summary.csv", index=False)
display(summary)

fig, ax = plt.subplots(figsize=(6.2, 4.0))
for kind, marker in (("simple", "o"), ("euler", "s"), ("log", "^")):
    data = summary[summary.method == kind]
    ax.loglog(data.h, data.rmse, marker=marker, lw=1.2, label=kind)
href = np.array(levels, dtype=float)
ax.loglog(href, np.sqrt(2) * sigma ** 2 * T * np.sqrt((T / href) / T),
          ":", color="gray", label=r"reference $h^{1/2}$")
ax.set(xlabel="grid step h (years)", ylabel=r"RMSE vs $\sigma^2T$",
       title="A2(b) coupled grids, M=5000")
ax.legend()
plt.show()

one_path = pd.DataFrame({
    "L": levels,
    "error_simple_path0": [coupled["simple"][j, 0] - sigma2T for j in range(5)],
    "error_euler_path0": [coupled["euler"][j, 0] - sigma2T for j in range(5)],
})
display(one_path)
print("A2(c): the same path's error changes sign across grids, so a single "
      "path cannot demonstrate a finite-grid identity.")'''

a3 = r'''import math
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

S, E, r, sigma, tau = 100.0, 105.0, 0.05, 0.20, 1.0
d1, d2 = bs_d(S, E, r, sigma, tau)
call, put = bs_prices(S, E, r, sigma, tau)
print({"d1": float(d1), "d2": float(d2), "call": float(call),
       "put": float(put),
       "parity_residual": float(call + E * math.exp(-r * tau) - put - S)})

spots = np.linspace(0.0, 200.0, 201)
calls, puts = bs_prices(spots, E, r, sigma, tau)
fig, ax = plt.subplots(figsize=(6.4, 4.0))
ax.plot(spots, calls, lw=1.6, label="call")
ax.plot(spots, puts, lw=1.6, label="put")
ax.plot(spots, np.maximum(spots - E, 0.0), ":", lw=1.0, label="call intrinsic")
ax.plot(spots, np.maximum(E - spots, 0.0), ":", lw=1.0, label="put intrinsic")
ax.axvline(E, color="gray", lw=0.8, ls="--")
ax.set(xlabel="spot S", ylabel="option value",
       title="A3(a) values for E=105, r=0.05, sigma=0.20, tau=1")
ax.legend()
plt.show()

degenerate = {
    "tau=0": bs_prices(100.0, E, r, sigma, 0.0),
    "S=0": bs_prices(0.0, E, r, sigma, 1.0),
    "sigma=0": bs_prices(100.0, E, r, 0.0, 1.0),
}
print({k: (float(v[0]), float(v[1])) for k, v in degenerate.items()})
for bad in ((-1.0, E, r, sigma, 1.0), (100.0, 0.0, r, sigma, 1.0),
            (100.0, E, r, -0.1, 1.0), (float("nan"), E, r, sigma, 1.0)):
    try:
        bs_prices(*bad)
        raise AssertionError("invalid input accepted")
    except ValueError:
        pass
print("invalid inputs rejected: 4/4")

pde_rows = []
for s in (80.0, 100.0, 120.0):
    for t in (0.25, 1.0):
        for j in range(4):
            hs, ht = 1.0 / 2 ** j, 0.01 / 2 ** j
            value = call_pde_residual(s, E, r, sigma, t, hs, ht)
            pde_rows.append({"S": s, "tau": t, "j": j, "hS": hs,
                             "h_tau": ht, "residual": value,
                             "abs": abs(value)})
pde = pd.DataFrame(pde_rows)
display(pde.pivot_table(index=["S", "tau"], columns="j", values="abs"))
pde_max = pde.groupby("j", as_index=False).agg(hS=("hS", "first"),
                                               max_abs=("abs", "max"))
display(pde_max)

fig, ax = plt.subplots(figsize=(6.0, 3.8))
ax.loglog(pde_max.hS, pde_max.max_abs, "o-")
ax.loglog(pde_max.hS, pde_max.max_abs.iloc[0] *
          (pde_max.hS / pde_max.hS.iloc[0]) ** 2, ":",
          color="gray", label=r"slope $h^2$")
ax.set(xlabel="hS (h_tau = 0.01 hS)", ylabel="maximum absolute residual",
       title="A3(b) PDE residual, central differences")
ax.legend()
plt.show()

rows = []
for n, seed in zip((1000, 10000, 100000), (4102030, 4102031, 4102032)):
    z = np.random.default_rng(seed).standard_normal(n)
    terminal, cpay, ppay = discounted_payoffs(S, E, r, sigma, tau, z)
    c_est, p_est = estimate(cpay), estimate(ppay)
    diff = estimate(cpay - ppay)
    rows.append({"N": n, "call": c_est["estimate"], "call_se": c_est["se"],
                 "call_low": c_est["low"], "call_high": c_est["high"],
                 "put": p_est["estimate"], "put_se": p_est["se"],
                 "put_low": p_est["low"], "put_high": p_est["high"],
                 "parity_diff": diff["estimate"],
                 "parity_se": diff["se"],
                 "parity_z": (diff["estimate"] - (S - E * math.exp(-r * tau)))
                              / diff["se"]})
mc = pd.DataFrame(rows)
mc.to_csv(RESULTS / "a3_mc_summary.csv", index=False)
display(mc)
print("formula call:", float(call), "formula put:", float(put))

fig, ax = plt.subplots(figsize=(6.0, 3.8))
ax.errorbar(mc.N, mc.call, yerr=1.959963984540054 * mc.call_se, fmt="o",
            capsize=4, label="Monte Carlo mean, 95% CI")
ax.axhline(float(call), color="C3", ls="--", label="formula")
ax.set_xscale("log")
ax.set(xlabel="terminal samples N", ylabel="call estimate",
       title="A3(c) exact terminal Monte Carlo, shared call/put samples")
ax.legend()
plt.show()'''

i2_markdown = r'''## I2 — pre-AI diagnosis and independent repair

### Pre-AI diagnosis (recorded before any model consultation)

The supplied artifact has four independent defects. (1) It inserts the
**physical drift** `mu=0.12` into `d1`; the risk-neutral formulas require `r`.
(2) It sets `d2 = d1 + scale`; the correct relation is `d2 = d1 - scale`.
(3) It discounts with `exp(+r*tau)`; discounting must use `exp(-r*tau)`.
(4) It has no validation and no valid branches for `tau=0`, `S=0`, or
`sigma=0`; `np.divide` silently produces inf/nan at expiry.

Three independent checks were designed before the model was asked anything:

* **C1 analytical benchmark**: the corrected default parameters must give
  `C=8.0213522351`, `P=7.9004418077` (A3(a)).
* **C2 financial identity/bound**: `C - P = S - E exp(-r tau)`, with call and
  put nonnegative and `max(S - E exp(-r tau), 0) <= C <= S`.
* **C3 boundary/invalid cases**: `tau=0` returns intrinsic values; `S=0`
  gives `C=0`, `P=E exp(-r tau)`; `sigma=0` gives discounted forward
  intrinsic; negative spot, negative volatility, negative tau, and nonfinite
  inputs raise `ValueError`.'''

i2_checks = r'''import math
import numpy as np

def run_checks(pricer, label):
    results = {}
    try:
        values = pricer()
        results["C1 call"] = values["call"]
        results["C1 call error"] = values["call"] - 8.021352235143176
        results["C1 put"] = values["put"]
        results["C1 put error"] = values["put"] - 7.9004418077181455
        results["C2 parity residual"] = (values["call"] - values["put"]
                                        - (100.0 - 105.0 * math.exp(-0.05)))
    except Exception as exc:
        results["C1/C2 exception"] = f"{type(exc).__name__}: {exc}"
    discount = math.exp(-0.05)
    cases = (
        ("C3 expiry", dict(tau=0.0), (0.0, 5.0)),
        ("C3 zero spot", dict(spot=0.0), (0.0, 105.0 * discount)),
        ("C3 zero vol", dict(volatility=0.0),
         (max(100.0 - 105.0 * discount, 0.0), max(105.0 * discount - 100.0, 0.0))),
    )
    for label_case, kwargs, expected in cases:
        try:
            values = pricer(**kwargs)
            found = (values["call"], values["put"])
            results[label_case] = found
            results[label_case + " finite"] = bool(np.all(np.isfinite(found)))
            results[label_case + " correct"] = bool(
                np.allclose(found, expected, atol=1e-8))
        except Exception as exc:
            results[label_case] = f"raised {type(exc).__name__}"
    try:
        pricer(spot=-1.0)
        results["C3 invalid spot"] = "accepted (defect)"
    except ValueError:
        results["C3 invalid spot"] = "raised ValueError (correct)"
    try:
        pricer(mu=float("nan"))
        results["C3 NaN mu"] = "accepted (defect)"
    except ValueError:
        results["C3 NaN mu"] = "raised ValueError (correct)"
    print(label)
    for key, value in results.items():
        print(f"  {key}: {value}")
    return results

before = run_checks(candidate_pricer, "BEFORE repair (supplied artifact)")'''

i2_final = r'''def repaired_pricer(spot=100.0, strike=105.0, rate=0.05,
                    volatility=0.20, tau=1.0, mu=0.12):
    """Corrected European pricer. ``mu`` is accepted but never used."""
    import math
    from scipy.special import ndtr

    values = (spot, strike, rate, volatility, tau, mu)
    if not all(isinstance(v, (int, float, np.integer, np.floating))
               and not isinstance(v, bool) for v in values):
        raise TypeError("inputs must be real scalars")
    if not all(math.isfinite(float(v)) for v in values):
        raise ValueError("inputs must be finite")
    if spot < 0.0 or strike <= 0.0 or volatility < 0.0 or tau < 0.0:
        raise ValueError("invalid sign: need spot>=0, strike>0, vol>=0, tau>=0")
    if tau == 0.0:
        return {"call": max(spot - strike, 0.0),
                "put": max(strike - spot, 0.0)}
    discount = math.exp(-rate * tau)
    if volatility == 0.0 or spot == 0.0:
        return {"call": max(spot - strike * discount, 0.0),
                "put": max(strike * discount - spot, 0.0)}
    scale = volatility * math.sqrt(tau)
    d1 = (math.log(spot / strike) + (rate + 0.5 * volatility ** 2) * tau) / scale
    d2 = d1 - scale
    call = spot * ndtr(d1) - strike * discount * ndtr(d2)
    put = strike * discount * ndtr(-d2) - spot * ndtr(-d1)
    return {"call": float(call), "put": float(put)}

after = run_checks(repaired_pricer, "AFTER repair (final code)")'''

impl_markdown = '''## Student implementations — completed

The next cell contains the completed implementations (the same source as
`code/student_tasks.py`, embedded here so the notebook is self-contained).
It includes validation, explicit degenerate branches, the calendar-time PDE
residual, and the paired Monte Carlo interface. Running the cell defines the
functions; the algorithm checks are in `code/test_student_tasks.py` and in the
experiment cells below.'''

nb = nbf.read(SCAFFOLD, as_version=4)
out = nbf.v4.new_notebook()
out.metadata = nb.metadata
out.nbformat = 4
out.nbformat_minor = 5
cells = []
for cell in nb.cells:
    if cell.cell_type == "code" and "required = {" in cell.source:
        cells.append(nbf.v4.new_code_cell(setup))
    elif cell.cell_type == "code" and "def gbm_from_increments" in cell.source:
        cells.append(nbf.v4.new_code_cell(impl))
    elif cell.cell_type == "code" and "TODO: A1 implementation" in cell.source:
        cells.append(nbf.v4.new_code_cell(a1))
    elif cell.cell_type == "code" and "TODO: A2 coupled" in cell.source:
        cells.append(nbf.v4.new_code_cell(a2))
    elif cell.cell_type == "code" and "TODO: A3 calculations" in cell.source:
        cells.append(nbf.v4.new_code_cell(a3))
    elif cell.cell_type == "markdown" and "Student implementations" in cell.source:
        cells.append(nbf.v4.new_markdown_cell(impl_markdown))
    elif cell.cell_type == "markdown" and "## Completion checklist" in cell.source:
        cells.append(nbf.v4.new_markdown_cell(i2_markdown))
        cells.append(nbf.v4.new_code_cell(i2_checks))
        cells.append(nbf.v4.new_code_cell(i2_final))
        cells.append(cell)
    else:
        cells.append(cell)

out.cells = cells
TARGET.parent.mkdir(parents=True, exist_ok=True)
nbf.write(out, TARGET)
print(f"wrote {TARGET} with {len(out.cells)} cells")
