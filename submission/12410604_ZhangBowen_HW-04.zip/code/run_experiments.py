"""Reproduce every HW-04 numerical result, CSV table, and figure.

Command (from the submission root):
    python code/run_experiments.py
"""
from __future__ import annotations

import json
import math
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy

import student_tasks as st

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
RESULTS.mkdir(exist_ok=True)
FIGURES.mkdir(exist_ok=True)

SEED_MAIN = 4102026
SEED_A1B = 4102027
SEED_A2 = 4102028
SEED_A2_COUPLED = 4102029
SEED_A3 = [4102030, 4102031, 4102032]

plt.rcParams.update({
    "figure.dpi": 150,
    "savefig.dpi": 150,
    "font.size": 9,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "legend.frameon": False,
    "figure.constrained_layout.use": True,
})


def savefig(fig, name: str) -> None:
    for suffix in (".png", ".pdf"):
        fig.savefig(FIGURES / f"{name}{suffix}", bbox_inches="tight")
    plt.close(fig)


def write_metadata() -> dict:
    metadata = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "seed_main": SEED_MAIN,
        "seeds": {"a1b": SEED_A1B, "a2_paths": SEED_A2,
                  "a2_coupled": SEED_A2_COUPLED, "a3": SEED_A3},
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__,
        "pandas": pd.__version__,
        "command": "python code/run_experiments.py",
        "gnu_rng": "numpy.random.default_rng (PCG64)",
    }
    (RESULTS / "run_metadata.json").write_text(
        json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    return metadata


# --------------------------------------------------------------------------
# A1
# --------------------------------------------------------------------------

def run_a1() -> dict:
    summary: dict = {"config_a": {"s0": 100.0, "mu": 0.05, "sigma": 0.20,
                                  "T": 2.0, "L": 500, "seed": SEED_MAIN},
                     "config_b": {"s0": 1.0, "mu": 0.05, "sigma": 0.30,
                                  "T": 1.0, "L": 10000, "seed": SEED_A1B}}

    rng_a = np.random.default_rng(SEED_MAIN)
    times_a, prices_a, dw_a = st.simulate_gbm(100.0, 0.05, 0.20, 2.0, 500, 1, rng_a)
    path_a = prices_a[0]
    pd.DataFrame({"time": times_a, "price": path_a}).to_csv(
        RESULTS / "a1_path_L500.csv", index=False, float_format="%.10g")
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    ax.plot(times_a, path_a, lw=1.0, color="C0")
    ax.set(xlabel="time t (years)", ylabel="stock price S(t)",
           title="A1(a) exact GBM path: S0=100, mu=0.05, sigma=0.20, L=500")
    savefig(fig, "a1_path_L500")

    rng_b = np.random.default_rng(SEED_A1B)
    times_b, prices_b, dw_b = st.simulate_gbm(1.0, 0.05, 0.30, 1.0, 10000, 1, rng_b)
    path_b = prices_b[0]
    pd.DataFrame({"time": times_b, "price": path_b}).to_csv(
        RESULTS / "a1_path_L10000.csv", index=False, float_format="%.10g")

    windows = [("a1_zoom_full", 1.0, "[0, 1]"),
               ("a1_zoom_0p1", 0.1, "[0, 0.1]"),
               ("a1_zoom_0p01", 0.01, "[0, 0.01]")]
    for name, upper, label in windows:
        mask = times_b <= upper + 1e-15
        fig, ax = plt.subplots(figsize=(6.4, 3.6))
        ax.plot(times_b[mask], path_b[mask], lw=1.1, color="C1")
        ax.set(xlabel="time t (years)", ylabel="stock price S(t)",
               title=f"A1(b) same path on {label}: S0=1, sigma=0.30, L=10^4")
        savefig(fig, name)

    log_increments = ((0.05 - 0.5 * 0.30 ** 2) * (1.0 / 10000)
                      + 0.30 * dw_b[0])
    identity_error = float(abs(math.log(path_b[-1] / path_b[0])
                               - log_increments.sum()))
    zero_vol = st.gbm_from_increments(1.0, 0.05, 0.0, 0.1, np.zeros(5))
    zero_vol_expected = np.exp(0.05 * 0.1 * np.arange(6))
    invalid_rejections = 0
    for bad in ((0.0, 0.05, 0.2, 0.1), (1.0, 0.05, -0.2, 0.1),
                (1.0, 0.05, 0.2, 0.0), (1.0, float("nan"), 0.2, 0.1)):
        try:
            st.gbm_from_increments(*bad, np.zeros(3))
        except ValueError:
            invalid_rejections += 1
    summary.update({
        "path_a": {"points": int(path_a.size),
                   "initial": float(path_a[0]),
                   "terminal": float(path_a[-1]),
                   "minimum": float(path_a.min()),
                   "all_positive": bool(np.all(path_a > 0))},
        "path_b": {"points": int(path_b.size),
                   "initial": float(path_b[0]),
                   "terminal": float(path_b[-1]),
                   "minimum": float(path_b.min()),
                   "all_positive": bool(np.all(path_b > 0)),
                   "terminal_log_identity_error": identity_error},
        "zero_volatility_max_error": float(np.max(np.abs(zero_vol - zero_vol_expected))),
        "invalid_parameter_rejections": f"{invalid_rejections}/4",
        "grid_steps_a": 500,
        "grid_steps_b": 10000,
        "figures": ["a1_path_L500", "a1_zoom_full", "a1_zoom_0p1", "a1_zoom_0p01"],
    })
    return summary


# --------------------------------------------------------------------------
# A2
# --------------------------------------------------------------------------

def _theory(kind: str, mu: float, sigma: float, h: float, L: int) -> tuple[float, float]:
    e2, var2 = st.squared_return_moments(mu, sigma, h, kind)
    return L * e2, L * var2


def run_a2() -> dict:
    S0, mu, sigma, T = 1.0, 0.05, 0.30, 0.5
    sigma2T = sigma ** 2 * T

    rng = np.random.default_rng(SEED_A2)
    times, prices, _ = st.simulate_gbm(S0, mu, sigma, T, 100, 10, rng)
    running = st.realized_variation(prices, "simple")
    pd.DataFrame(np.column_stack([times, prices.T])).to_csv(
        RESULTS / "a2_prices_10paths.csv", index=False, header=False, float_format="%.10g")
    pd.DataFrame(np.column_stack([times, running.T])).to_csv(
        RESULTS / "a2_running_sums.csv", index=False, header=False, float_format="%.10g")

    fig, ax = plt.subplots(figsize=(6.4, 3.8))
    for j in range(10):
        ax.plot(times, running[j], lw=0.8, alpha=0.75, color="C0")
    ax.plot(times, sigma ** 2 * times, color="black", lw=2.0,
            label=r"$\sigma^2 t$ (continuous limit)")
    ax.set(xlabel="time t (years)",
           ylabel=r"running sum of squared simple returns",
           title="A2(a) 10 exact GBM paths, L=100, h=0.005")
    ax.legend()
    savefig(fig, "a2_running_sums")

    levels = [25, 50, 100, 200, 400]
    M = 5000
    rng_c = np.random.default_rng(SEED_A2_COUPLED)
    coupled = st.coupled_variation(mu, sigma, T, levels, M, rng_c, batch=250)

    rows = []
    long_rows = []
    for kind in ("simple", "euler", "log"):
        theory_kind = "exact_simple" if kind == "simple" else kind
        for j, L in enumerate(levels):
            values = coupled[kind][j]
            h = T / L
            e_theory, var_theory = _theory(theory_kind, mu, sigma, h, L)
            mean = float(values.mean())
            var = float(values.var(ddof=1))
            se = float(values.std(ddof=1) / math.sqrt(M))
            rows.append({
                "method": kind, "L": L, "h": h, "paths": M,
                "mean": mean, "variance": var,
                "bias_vs_sigma2T": mean - sigma2T,
                "rmse_vs_sigma2T": float(np.sqrt(np.mean((values - sigma2T) ** 2))),
                "se_mean": se,
                "theory_mean": e_theory,
                "theory_variance": var_theory,
                "mean_minus_theory": mean - e_theory,
                "variance_ratio": var / var_theory,
            })
            for i, value in enumerate(values):
                long_rows.append((kind, L, i, float(value)))
    summary = pd.DataFrame(rows)
    summary.to_csv(RESULTS / "a2_summary.csv", index=False, float_format="%.10g")
    pd.DataFrame(long_rows, columns=["method", "L", "path", "terminal_sum"]).to_csv(
        RESULTS / "a2_terminal_sums.csv", index=False, float_format="%.10g")

    single = []
    for kind in ("simple", "euler", "log"):
        for j, L in enumerate(levels):
            single.append({"method": kind, "L": L, "h": T / L,
                           "error_path0": float(coupled[kind][j, 0] - sigma2T)})
    pd.DataFrame(single).to_csv(
        RESULTS / "a2_single_path_errors.csv", index=False, float_format="%.10g")

    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    styles = {"simple": ("o", "C0", "exact GBM simple return"),
              "euler": ("s", "C1", r"Euler $\mu h+\sigma\Delta W$"),
              "log": ("^", "C2", "exact log return")}
    for kind, (marker, color, label) in styles.items():
        data = summary[summary.method == kind]
        ax.loglog(data.h, data.rmse_vs_sigma2T, marker=marker, color=color,
                  lw=1.2, label=label)
    href = summary[summary.method == "euler"].h.to_numpy()
    ax.loglog(href, math.sqrt(2) * sigma ** 2 * T * np.sqrt(href / T),
              ls=":", color="gray", lw=1.0, label=r"reference slope $h^{1/2}$")
    ax.loglog(href, 4 * sigma ** 2 * T * href / T, ls="--", color="gray",
              lw=1.0, label=r"reference slope $h^{1}$")
    ax.set(xlabel="grid step h (years)",
           ylabel=r"RMSE of terminal sum vs $\sigma^2T$",
           title="A2(b) coupled-grid RMSE, M=5000, levels 25 to 400")
    ax.legend(fontsize=8)
    savefig(fig, "a2_rmse_convergence")
    return {"summary": rows, "levels": levels, "paths": M,
            "sigma2T": sigma2T}


# --------------------------------------------------------------------------
# A3
# --------------------------------------------------------------------------

def run_a3() -> dict:
    S, E, r, sigma, tau = 100.0, 105.0, 0.05, 0.20, 1.0
    d1, d2 = st.bs_d(S, E, r, sigma, tau)
    call, put = st.bs_prices(S, E, r, sigma, tau)
    call, put = float(call), float(put)
    parity_residual = call + E * math.exp(-r * tau) - put - S

    benchmark = {
        "spot": S, "strike": E, "rate": r, "volatility": sigma, "tau": tau,
        "d1": float(d1), "d2": float(d2), "call": call, "put": put,
        "parity_residual": float(parity_residual),
        "discount_factor": math.exp(-r * tau),
        "forward": S - E * math.exp(-r * tau),
    }
    (RESULTS / "a3_benchmark.json").write_text(
        json.dumps(benchmark, indent=2) + "\n", encoding="utf-8")

    spots = np.linspace(0.0, 200.0, 201)
    calls, puts = st.bs_prices(spots, E, r, sigma, tau)
    pd.DataFrame({"spot": spots, "call": calls, "put": puts,
                  "call_intrinsic": np.maximum(spots - E, 0.0),
                  "put_intrinsic": np.maximum(E - spots, 0.0),
                  "parity_residual": calls + E * math.exp(-r * tau) - puts - spots}
                 ).to_csv(RESULTS / "a3_price_curve.csv", index=False,
                          float_format="%.10g")

    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    ax.plot(spots, calls, color="C0", lw=1.6, label="call C(S,tau)")
    ax.plot(spots, puts, color="C1", lw=1.6, label="put P(S,tau)")
    ax.plot(spots, np.maximum(spots - E, 0.0), ":", color="C0", lw=1.0,
            label="call intrinsic")
    ax.plot(spots, np.maximum(E - spots, 0.0), ":", color="C1", lw=1.0,
            label="put intrinsic")
    ax.axvline(E, color="gray", lw=0.8, ls="--")
    ax.set(xlabel="spot S", ylabel="option value",
           title="A3(a) European values: E=105, r=0.05, sigma=0.20, tau=1")
    ax.legend()
    savefig(fig, "a3_price_curve")

    validation_rows = []
    for s in (0.0, 50.0, 100.0, 105.0, 150.0, 200.0):
        for t in (0.0, 0.25, 1.0):
            c, p = st.bs_prices(s, E, r, sigma, t)
            c, p = float(c), float(p)
            validation_rows.append({
                "spot": s, "tau": t, "call": c, "put": p,
                "parity_residual": c + E * math.exp(-r * t) - p - s,
                "call_lower_bound": max(s - E * math.exp(-r * t), 0.0),
                "call_upper_bound": s, "put_lower_bound": max(E * math.exp(-r * t) - s, 0.0),
            })
    for s2, sig2, t2, label in ((0.0, 0.20, 1.0, "zero_spot"),
                                (100.0, 0.0, 1.0, "zero_vol"),
                                (100.0, 0.20, 0.0, "expiry"),
                                (100.0, 0.0, 0.0, "zero_spot_expiry_zero_vol")):
        c, p = st.bs_prices(s2, E, r, sig2, t2)
        validation_rows.append({"spot": s2, "tau": t2, "call": float(c), "put": float(p),
                                "parity_residual": float(c + E * math.exp(-r * t2) - p - s2),
                                "call_lower_bound": max(s2 - E * math.exp(-r * t2), 0.0),
                                "call_upper_bound": s2,
                                "put_lower_bound": max(E * math.exp(-r * t2) - s2, 0.0),
                                "case": label})
    pd.DataFrame(validation_rows).to_csv(
        RESULTS / "a3_validation.csv", index=False, float_format="%.10g")

    pde_rows = []
    for s in (80.0, 100.0, 120.0):
        for t in (0.25, 1.0):
            for j in range(4):
                hs, ht = 1.0 / 2 ** j, 0.01 / 2 ** j
                residual = st.call_pde_residual(s, E, r, sigma, t, hs, ht)
                pde_rows.append({"spot": s, "tau": t, "j": j,
                                 "hS": hs, "h_tau": ht, "residual": residual,
                                 "abs_residual": abs(residual)})
    pde = pd.DataFrame(pde_rows)
    pde.to_csv(RESULTS / "a3_pde_residuals.csv", index=False, float_format="%.10g")
    pde_max = pde.groupby("j", as_index=False).agg(
        hS=("hS", "first"), h_tau=("h_tau", "first"),
        max_abs_residual=("abs_residual", "max"))
    pde_max.to_csv(RESULTS / "a3_pde_max.csv", index=False, float_format="%.10g")

    fig, ax = plt.subplots(figsize=(6.0, 3.8))
    ax.loglog(pde_max.hS, pde_max.max_abs_residual, "o-", color="C3",
              label="max over S and tau")
    ref = pde_max.max_abs_residual.iloc[0] * (pde_max.hS / pde_max.hS.iloc[0]) ** 2
    ax.loglog(pde_max.hS, ref, ":", color="gray", label=r"reference slope $h^2$")
    ax.set(xlabel="spot step hS (with h_tau = 0.01 hS)",
           ylabel="maximum absolute PDE residual",
           title="A3(b) central-difference residual, j=0..3")
    ax.legend()
    savefig(fig, "a3_pde_residual")

    mc_rows = []
    ns = [1000, 10000, 100000]
    call_estimates = []
    formula_call = call
    formula_put = put
    parity_target = S - E * math.exp(-r * tau)
    for n, seed in zip(ns, SEED_A3):
        rng = np.random.default_rng(seed)
        z = rng.standard_normal(n)
        terminal, cpay, ppay = st.discounted_payoffs(S, E, r, sigma, tau, z)
        c_est, p_est = st.estimate(cpay), st.estimate(ppay)
        paired = cpay - ppay
        diff = st.estimate(paired)
        coverage_call = c_est["low"] <= formula_call <= c_est["high"]
        coverage_put = p_est["low"] <= formula_put <= p_est["high"]
        mc_rows.append({
            "N": n, "seed": seed,
            "call_mean": c_est["estimate"], "call_se": c_est["se"],
            "call_low": c_est["low"], "call_high": c_est["high"],
            "call_bias": c_est["estimate"] - formula_call,
            "call_covered": bool(coverage_call),
            "put_mean": p_est["estimate"], "put_se": p_est["se"],
            "put_low": p_est["low"], "put_high": p_est["high"],
            "put_bias": p_est["estimate"] - formula_put,
            "put_covered": bool(coverage_put),
            "paired_diff_mean": diff["estimate"], "paired_diff_se": diff["se"],
            "paired_target": parity_target,
            "paired_z": (diff["estimate"] - parity_target) / diff["se"],
            "terminal_mean": float(terminal.mean()),
            "terminal_theory_mean": S * math.exp(r * tau),
            "terminal_min": float(terminal.min()),
        })
        call_estimates.append((n, c_est["estimate"], c_est["se"]))
        np.savez_compressed(RESULTS / f"a3_terminal_samples_N{n}.npz",
                            z=z, terminal=terminal, call_payoff=cpay,
                            put_payoff=ppay)
        if n == 1000:
            pd.DataFrame({"z": z, "terminal": terminal,
                          "discounted_call_payoff": cpay,
                          "discounted_put_payoff": ppay}).to_csv(
                RESULTS / "a3_terminal_samples_N1000.csv", index=False,
                float_format="%.10g")
    mc = pd.DataFrame(mc_rows)
    mc.to_csv(RESULTS / "a3_mc_summary.csv", index=False, float_format="%.10g")

    fig, ax = plt.subplots(figsize=(6.0, 3.8))
    ns_arr = np.array([row[0] for row in call_estimates], dtype=float)
    means = np.array([row[1] for row in call_estimates])
    ses = np.array([row[2] for row in call_estimates])
    ax.errorbar(ns_arr, means, yerr=1.959963984540054 * ses, fmt="o",
                capsize=4, color="C0", label="Monte Carlo mean and 95% CI")
    ax.axhline(formula_call, color="C3", ls="--", label="Black-Scholes formula")
    ax.set_xscale("log")
    ax.set(xlabel="number of terminal samples N", ylabel="call estimate",
           title="A3(c) exact terminal Monte Carlo, shared call/put samples")
    ax.legend()
    savefig(fig, "a3_mc_convergence")
    return {"benchmark": benchmark, "mc": mc_rows, "pde_max": pde_max.to_dict("records")}


def main() -> None:
    metadata = write_metadata()
    a1 = run_a1()
    a2 = run_a2()
    a3 = run_a3()
    (RESULTS / "a1_checks.json").write_text(
        json.dumps(a1, indent=2) + "\n", encoding="utf-8")
    print("metadata:", json.dumps(metadata, indent=2))
    print("A1 checks:", json.dumps(a1, indent=2))
    print("A2 summary:")
    print(pd.DataFrame(a2["summary"]).to_string(index=False))
    print("A3 benchmark:", json.dumps(a3["benchmark"], indent=2))
    print("A3 Monte Carlo:")
    print(pd.DataFrame(a3["mc"]).to_string(index=False))
    print("A3 PDE max:")
    print(pd.DataFrame(a3["pde_max"]).to_string(index=False))


if __name__ == "__main__":
    main()
