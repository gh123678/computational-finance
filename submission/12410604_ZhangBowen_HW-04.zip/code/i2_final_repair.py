"""Final I2 repair: corrected risk-neutral European pricer.

The student's final routine, after the model-proposed patch was tested and
revised. ``mu`` is retained for signature compatibility and validated, but it
never enters the price.
"""
from __future__ import annotations

import math

import numpy as np
from scipy.special import ndtr


def repaired_pricer(spot=100.0, strike=105.0, rate=0.05,
                    volatility=0.20, tau=1.0, mu=0.12):
    values = (spot, strike, rate, volatility, tau, mu)
    if not all(isinstance(v, (int, float, np.integer, np.floating))
               and not isinstance(v, bool) for v in values):
        raise TypeError("inputs must be real scalars")
    S, E, r, sigma, t, mu_value = (float(v) for v in values)
    if not all(math.isfinite(v) for v in (S, E, r, sigma, t, mu_value)):
        raise ValueError("inputs must be finite")
    if S < 0.0 or E <= 0.0 or sigma < 0.0 or t < 0.0:
        raise ValueError("require spot>=0, strike>0, volatility>=0, tau>=0")
    if t == 0.0:
        return {"call": max(S - E, 0.0), "put": max(E - S, 0.0)}
    discount = math.exp(-r * t)
    if sigma == 0.0 or S == 0.0:
        forward_strike = E * discount
        return {"call": max(S - forward_strike, 0.0),
                "put": max(forward_strike - S, 0.0)}
    scale = sigma * math.sqrt(t)
    d1 = (math.log(S / E) + (r + 0.5 * sigma ** 2) * t) / scale
    d2 = d1 - scale
    call = S * ndtr(d1) - E * discount * ndtr(d2)
    put = E * discount * ndtr(-d2) - S * ndtr(-d1)
    if not (math.isfinite(call) and math.isfinite(put)):
        raise ArithmeticError("nonfinite price for finite inputs")
    return {"call": float(call), "put": float(put)}


if __name__ == "__main__":
    print(repaired_pricer())
