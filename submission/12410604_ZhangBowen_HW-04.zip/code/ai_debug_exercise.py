"""I2: deliberately flawed teaching artifact, NOT an observed AI response.

Keep this original unchanged. Record your own diagnosis before consulting an LLM.
"""
import numpy as np
from scipy.special import ndtr


def candidate_pricer(spot=100.0, strike=105.0, rate=0.05,
                     volatility=0.20, tau=1.0, mu=0.12):
    scale = volatility * np.sqrt(tau)
    d1 = np.divide(np.log(spot / strike) + (mu + 0.5*volatility**2)*tau, scale)
    d2 = d1 + scale
    discount = np.exp(rate * tau)
    call = spot * ndtr(d1) - strike * discount * ndtr(d2)
    put = strike * discount * ndtr(-d2) - spot * ndtr(-d1)
    return {'call': float(call), 'put': float(put)}


if __name__ == '__main__':
    print(candidate_pricer())
