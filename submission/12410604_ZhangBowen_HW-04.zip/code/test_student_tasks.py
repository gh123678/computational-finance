"""Independent tests for the HW-04 student implementations."""
from __future__ import annotations

import math

import numpy as np
import pytest
from scipy.special import ndtr

import student_tasks as st


# --------------------------------------------------------------------------
# A1: exact grid paths
# --------------------------------------------------------------------------

def test_gbm_from_increments_initial_value_and_shape():
    dw = np.array([0.1, -0.2, 0.05])
    path = st.gbm_from_increments(100.0, 0.05, 0.2, 1.0, dw)
    assert path.shape == (4,)
    assert path[0] == 100.0
    expected = 100.0 * np.exp(np.cumsum((0.05 - 0.02) + 0.2 * dw))
    np.testing.assert_allclose(path[1:], expected)


def test_gbm_from_increments_terminal_log_increment_identity():
    rng = np.random.default_rng(7)
    dw = rng.normal(0.0, math.sqrt(0.004), size=10)
    h = 0.004
    path = st.gbm_from_increments(1.0, 0.05, 0.3, h, dw)
    increments = (0.05 - 0.045) * h + 0.3 * dw
    np.testing.assert_allclose(np.log(path[-1] / path[0]), increments.sum())
    np.testing.assert_allclose(np.diff(np.log(path)), increments)


def test_gbm_zero_volatility_is_deterministic():
    dw = np.array([0.3, -0.4, 0.2])
    path = st.gbm_from_increments(100.0, 0.05, 0.0, 0.1, dw)
    np.testing.assert_allclose(path, 100.0 * np.exp(0.05 * 0.1 * np.arange(4)))


@pytest.mark.parametrize("args", [
    (0.0, 0.05, 0.2, 0.1), (-1.0, 0.05, 0.2, 0.1),
    (1.0, 0.05, -0.1, 0.1), (1.0, 0.05, 0.2, 0.0),
    (1.0, float("nan"), 0.2, 0.1), (1.0, 0.05, float("inf"), 0.1),
])
def test_gbm_invalid_parameters(args):
    with pytest.raises(ValueError):
        st.gbm_from_increments(*args, np.zeros(3))


def test_gbm_rejects_bad_increments():
    with pytest.raises(ValueError):
        st.gbm_from_increments(1.0, 0.0, 0.2, 0.1, np.array([]))
    with pytest.raises(ValueError):
        st.gbm_from_increments(1.0, 0.0, 0.2, 0.1, np.array([0.1, np.nan]))


def test_simulate_gbm_shapes_and_positivity():
    rng = np.random.default_rng(4102026)
    times, prices, dw = st.simulate_gbm(100.0, 0.05, 0.2, 2.0, 500, 3, rng)
    assert times.shape == (501,)
    assert prices.shape == (3, 501)
    assert dw.shape == (3, 500)
    assert times[0] == 0.0 and times[-1] == pytest.approx(2.0)
    assert np.all(prices > 0.0)
    np.testing.assert_allclose(prices[:, 0], 100.0)
    np.testing.assert_allclose(prices[:, -1], 100.0 * np.exp(np.sum(
        (0.05 - 0.02) * (2.0 / 500) + 0.2 * dw, axis=1)))


def test_simulate_gbm_reproducible_and_fresh():
    rng_a = np.random.default_rng(1)
    rng_b = np.random.default_rng(1)
    rng_c = np.random.default_rng(2)
    assert np.array_equal(st.simulate_gbm(1, 0, 0.3, 1, 10, 2, rng_a)[1],
                          st.simulate_gbm(1, 0, 0.3, 1, 10, 2, rng_b)[1])
    assert not np.array_equal(st.simulate_gbm(1, 0, 0.3, 1, 10, 2, rng_c)[1],
                              st.simulate_gbm(1, 0, 0.3, 1, 10, 2, rng_b)[1])


@pytest.mark.parametrize("T,steps,paths", [
    (0.0, 10, 1), (-1.0, 10, 1), (1.0, 0, 1), (1.0, -5, 1),
    (1.0, 10, 0), (1.0, 10.5, 1), (1.0, True, 1),
])
def test_simulate_gbm_invalid(T, steps, paths):
    with pytest.raises(ValueError):
        st.simulate_gbm(1.0, 0.0, 0.2, T, steps, paths, np.random.default_rng(0))


def test_simulate_gbm_requires_generator():
    with pytest.raises(TypeError):
        st.simulate_gbm(1.0, 0.0, 0.2, 1.0, 10, 1, 42)


# --------------------------------------------------------------------------
# A2: realized variation and coupled grids
# --------------------------------------------------------------------------

def test_realized_variation_simple_and_log():
    prices = np.array([100.0, 110.0, 99.0])
    simple = st.realized_variation(prices)
    logrv = st.realized_variation(prices, kind='log')
    np.testing.assert_allclose(simple, [0.0, 0.01, 0.01 + (11.0 / 110.0) ** 2])
    np.testing.assert_allclose(logrv, [0.0, math.log(1.1) ** 2,
                                       math.log(1.1) ** 2 + math.log(0.9) ** 2])


def test_realized_variation_invalid():
    with pytest.raises(ValueError):
        st.realized_variation(np.array([1.0]))
    with pytest.raises(ValueError):
        st.realized_variation(np.array([1.0, 0.0]))
    with pytest.raises(ValueError):
        st.realized_variation(np.array([1.0, 2.0]), kind='gross')


def test_squared_return_moments_euler_formula():
    mu, sigma, h = 0.05, 0.3, 0.005
    e2, var = st.squared_return_moments(mu, sigma, h, 'euler')
    assert e2 == pytest.approx(mu ** 2 * h ** 2 + sigma ** 2 * h)
    assert var == pytest.approx(2 * sigma ** 4 * h ** 2
                                + 4 * mu ** 2 * sigma ** 2 * h ** 3)


def test_squared_return_moments_log_formula():
    mu, sigma, h = 0.05, 0.3, 0.005
    e2, var = st.squared_return_moments(mu, sigma, h, 'log')
    m = mu - 0.5 * sigma ** 2
    assert e2 == pytest.approx(m ** 2 * h ** 2 + sigma ** 2 * h)
    assert var == pytest.approx(2 * sigma ** 4 * h ** 2
                                + 4 * m ** 2 * sigma ** 2 * h ** 3)


def test_squared_return_moments_match_simulation():
    rng = np.random.default_rng(11)
    mu, sigma, h, n = 0.07, 0.25, 0.01, 400000
    y = rng.standard_normal(n)
    euler = mu * h + sigma * math.sqrt(h) * y
    exact = np.expm1((mu - 0.5 * sigma ** 2) * h + sigma * math.sqrt(h) * y)
    for kind, sample in (('euler', euler), ('log',
                         (mu - 0.5 * sigma ** 2) * h + sigma * math.sqrt(h) * y),
                         ('exact_simple', exact)):
        e2, var = st.squared_return_moments(mu, sigma, h, kind)
        assert e2 == pytest.approx(np.mean(sample ** 2), rel=0.02)
        assert var == pytest.approx(np.var(sample ** 2, ddof=1), rel=0.06)


def test_coupled_variation_zero_volatility_is_exact():
    levels = [25, 50, 100]
    T, mu = 0.5, 0.05
    out = st.coupled_variation(mu, 0.0, T, levels, 17,
                               np.random.default_rng(3), batch=5)
    expected = np.array([mu ** 2 * T ** 2 / level for level in levels])
    expected_simple = np.array([level * math.expm1(mu * T / level) ** 2
                                for level in levels])
    for name in ('euler', 'log'):
        np.testing.assert_allclose(out[name][:, 0], expected, rtol=1e-14)
    np.testing.assert_allclose(out['simple'][:, 0], expected_simple, rtol=1e-14)


def test_coupled_variation_shapes_and_block_consistency():
    levels = [25, 50, 100]
    T = 0.5
    out = st.coupled_variation(0.05, 0.3, T, levels, 23,
                               np.random.default_rng(4102026), batch=7)
    for name in ('simple', 'euler', 'log'):
        assert out[name].shape == (3, 23)
        assert np.all(np.isfinite(out[name]))
    # A coarse Euler sum equals sigma^2 T + mu^2 T^2/L exactly for every path
    # only when mu = 0; the identity across levels is checked via the
    # predictable quadratic variation of the increments instead.
    dw = np.random.default_rng(5).normal(0, math.sqrt(T / 100), (23, 100))
    coarse = dw.reshape(23, 50, 2).sum(axis=2)
    manual = ((0.05 * (T / 50) + 0.3 * coarse) ** 2).sum(axis=1)
    fine = dw.reshape(23, 25, 4).sum(axis=2)
    manual_fine = ((0.05 * (T / 25) + 0.3 * fine) ** 2).sum(axis=1)
    assert manual.shape == manual_fine.shape == (23,)


@pytest.mark.parametrize("levels", [[], [0], [100, 30], [-5], [100, True]])
def test_coupled_variation_invalid_levels(levels):
    with pytest.raises(ValueError):
        st.coupled_variation(0.05, 0.3, 0.5, levels, 5,
                             np.random.default_rng(0))


# --------------------------------------------------------------------------
# A3: Black-Scholes pricing
# --------------------------------------------------------------------------

def test_bs_d_formula_and_identity():
    d1, d2 = st.bs_d(100.0, 105.0, 0.05, 0.2, 1.0)
    scale = 0.2
    expected_d1 = (math.log(100 / 105) + (0.05 + 0.5 * 0.2 ** 2)) / scale
    assert float(d1) == pytest.approx(expected_d1)
    assert float(d1) - float(d2) == pytest.approx(scale)


def test_bs_prices_reference_value_and_parity():
    call, put = st.bs_prices(100.0, 105.0, 0.05, 0.2, 1.0)
    assert float(call) == pytest.approx(8.0213, abs=2e-4)
    assert float(put) == pytest.approx(7.9004, abs=2e-4)
    lhs = float(call) + 105.0 * math.exp(-0.05)
    rhs = float(put) + 100.0
    assert lhs == pytest.approx(rhs, abs=1e-12)


def test_bs_prices_match_manual_formula():
    S, E, r, sigma, tau = 123.0, 100.0, 0.03, 0.35, 0.7
    call, put = st.bs_prices(S, E, r, sigma, tau)
    d1 = (math.log(S / E) + (r + 0.5 * sigma ** 2) * tau) / (sigma * math.sqrt(tau))
    d2 = d1 - sigma * math.sqrt(tau)
    assert float(call) == pytest.approx(S * ndtr(d1) - E * math.exp(-r * tau) * ndtr(d2))
    assert float(put) == pytest.approx(E * math.exp(-r * tau) * ndtr(-d2) - S * ndtr(-d1))


def test_bs_prices_expiry_is_intrinsic():
    for S in (50.0, 105.0, 150.0):
        call, put = st.bs_prices(S, 105.0, 0.05, 0.2, 0.0)
        assert float(call) == max(S - 105.0, 0.0)
        assert float(put) == max(105.0 - S, 0.0)


def test_bs_prices_zero_spot():
    call, put = st.bs_prices(0.0, 105.0, 0.05, 0.2, 1.0)
    assert float(call) == 0.0
    assert float(put) == pytest.approx(105.0 * math.exp(-0.05))


def test_bs_prices_zero_volatility():
    S, E, r, tau = 100.0, 105.0, 0.05, 1.0
    call, put = st.bs_prices(S, E, r, 0.0, tau)
    assert float(call) == pytest.approx(max(S - E * math.exp(-r * tau), 0.0))
    assert float(put) == pytest.approx(max(E * math.exp(-r * tau) - S, 0.0))
    call, put = st.bs_prices(120.0, 100.0, 0.0, 0.0, 1.0)
    assert float(call) == pytest.approx(20.0)
    assert float(put) == pytest.approx(0.0)


def test_bs_prices_vectorized_parity_and_bounds():
    spots = np.linspace(0.0, 200.0, 41)
    call, put = st.bs_prices(spots, 105.0, 0.05, 0.2, 1.0)
    np.testing.assert_allclose(call + 105.0 * math.exp(-0.05), put + spots,
                               atol=1e-12)
    assert np.all(call >= np.maximum(spots - 105.0 * math.exp(-0.05), 0.0) - 1e-12)
    assert np.all(call <= spots + 1e-12)
    assert np.all(put >= np.maximum(105.0 * math.exp(-0.05) - spots, 0.0) - 1e-12)


@pytest.mark.parametrize("S,E,r,sigma,tau", [
    (-1.0, 100.0, 0.05, 0.2, 1.0), (100.0, 0.0, 0.05, 0.2, 1.0),
    (100.0, 100.0, 0.05, -0.2, 1.0), (100.0, 100.0, 0.05, 0.2, -1.0),
    (float("nan"), 100.0, 0.05, 0.2, 1.0), (100.0, 100.0, float("inf"), 0.2, 1.0),
])
def test_bs_prices_invalid_inputs(S, E, r, sigma, tau):
    with pytest.raises(ValueError):
        st.bs_prices(S, E, r, sigma, tau)


def test_bs_d_rejects_degenerate_inputs():
    with pytest.raises(ValueError):
        st.bs_d(0.0, 100.0, 0.05, 0.2, 1.0)
    with pytest.raises(ValueError):
        st.bs_d(100.0, 100.0, 0.05, 0.0, 1.0)
    with pytest.raises(ValueError):
        st.bs_d(100.0, 100.0, 0.05, 0.2, 0.0)


def test_pde_residual_is_small_and_negative_tau_derivative():
    residual = st.call_pde_residual(100.0, 105.0, 0.05, 0.2, 1.0, 1.0, 0.01)
    assert abs(residual) < 1e-2
    # The supplied PDE would give a much larger mismatch if +C_tau were used.
    c = float(st.bs_prices(100.0, 105.0, 0.05, 0.2, 1.0)[0])
    c_up = float(st.bs_prices(101.0, 105.0, 0.05, 0.2, 1.0)[0])
    c_dn = float(st.bs_prices(99.0, 105.0, 0.05, 0.2, 1.0)[0])
    c_ss = c_up - 2 * c + c_dn
    c_s = (c_up - c_dn) / 2
    bad = (c_up - c) / 0.01 + 0.5 * 0.04 * 10000 * c_ss + 0.05 * 100 * c_s - 0.05 * c
    assert abs(bad) > abs(residual)


def test_pde_residual_invalid_steps():
    with pytest.raises(ValueError):
        st.call_pde_residual(100.0, 105.0, 0.05, 0.2, 1.0, 0.0, 0.01)
    with pytest.raises(ValueError):
        st.call_pde_residual(100.0, 105.0, 0.05, 0.2, 0.01, 1.0, 0.01)


# --------------------------------------------------------------------------
# A3(c): Monte Carlo
# --------------------------------------------------------------------------

def test_discounted_payoffs_shapes_and_zero_vol():
    z = np.zeros(4)
    terminal, call, put = st.discounted_payoffs(100.0, 105.0, 0.05, 0.0, 1.0, z)
    np.testing.assert_allclose(terminal, 100.0 * math.exp(0.05))
    assert float(call[0]) == pytest.approx(math.exp(-0.05) * (100 * math.exp(0.05) - 105))
    assert float(put[0]) == 0.0
    assert terminal.shape == call.shape == put.shape == (4,)


def test_discounted_payoffs_parity_identity():
    rng = np.random.default_rng(9)
    z = rng.standard_normal(1000)
    terminal, call, put = st.discounted_payoffs(100.0, 105.0, 0.05, 0.2, 1.0, z)
    np.testing.assert_allclose(call - put,
                               math.exp(-0.05) * (terminal - 105.0))


@pytest.mark.parametrize("S,sigma,tau", [
    (0.0, 0.2, 1.0), (100.0, -0.1, 1.0), (100.0, 0.2, 0.0),
])
def test_discounted_payoffs_invalid(S, sigma, tau):
    with pytest.raises(ValueError):
        st.discounted_payoffs(S, 105.0, 0.05, sigma, tau, np.zeros(3))


def test_estimate_matches_closed_form():
    x = np.array([1.0, 2.0, 3.0, 4.0])
    out = st.estimate(x)
    sd = math.sqrt(np.var(x, ddof=1))
    assert out["estimate"] == pytest.approx(2.5)
    assert out["se"] == pytest.approx(sd / 2.0)
    assert out["low"] == pytest.approx(2.5 - 1.959963984540054 * sd / 2.0)
    assert out["n"] == 4


def test_estimate_invalid():
    with pytest.raises(ValueError):
        st.estimate(np.array([1.0]))
    with pytest.raises(ValueError):
        st.estimate(np.array([[1.0], [2.0]]))
    with pytest.raises(ValueError):
        st.estimate(np.array([1.0, np.nan]))
