"""Minimal DeepSeek API client used to record the I1/I2 transcripts.

The API key is read from ANTHROPIC_AUTH_TOKEN and is never written to disk.
Only visible text blocks are stored; provider-side reasoning blocks are not
part of the reply shown to the user and are omitted.
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ENDPOINT = "https://api.deepseek.com/anthropic/v1/messages"
LOG_DIR = Path(__file__).resolve().parent.parent / "ai_logs"
LOG_DIR.mkdir(exist_ok=True)

MODELS = {
    "deepseek-v4-pro": "DeepSeek-V4-Pro",
    "deepseek-flash": "DeepSeek-V4.1-Flash",
}


def chat(model: str, messages: list[dict], max_tokens: int = 4000) -> dict:
    token = os.environ.get("ANTHROPIC_AUTH_TOKEN")
    if not token:
        raise RuntimeError("ANTHROPIC_AUTH_TOKEN is not set")
    payload = json.dumps({"model": model, "max_tokens": max_tokens,
                          "thinking": {"type": "disabled"},
                          "messages": messages}).encode("utf-8")
    request = urllib.request.Request(
        ENDPOINT, data=payload,
        headers={"content-type": "application/json", "x-api-key": token,
                 "anthropic-version": "2023-06-01"})
    last_error: Exception | None = None
    for attempt in range(4):
        try:
            with urllib.request.urlopen(request, timeout=180) as response:
                data = json.load(response)
            blocks = data.get("content") or []
            text = "".join(block.get("text", "") for block in blocks
                           if block.get("type") == "text")
            if not text:
                raise RuntimeError(f"empty text reply: {data.get('stop_reason')}")
            meta = {"model": data.get("model"), "usage": data.get("usage"),
                    "stop_reason": data.get("stop_reason"),
                    "received_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
            return {"text": text, "meta": meta}
        except (urllib.error.URLError, TimeoutError) as exc:
            last_error = exc
            time.sleep(2 + 3 * attempt)
    raise RuntimeError(f"API call failed after retries: {last_error}")


def new_session(path: Path, model: str, purpose: str) -> dict:
    session = {
        "provider": "DeepSeek",
        "display_name": MODELS.get(model, model),
        "model_id": model,
        "access": "DeepSeek Anthropic-compatible messages API; text only; "
                  "no browsing, code execution, or external tools enabled",
        "date_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "purpose": purpose,
        "messages": [],
        "replies": [],
    }
    save_session(path, session)
    return session


def save_session(path: Path, session: dict) -> None:
    path.write_text(json.dumps(session, indent=2, ensure_ascii=False) + "\n",
                    encoding="utf-8")


def append_turn(path: Path, session: dict, prompt: str, max_tokens: int = 4000) -> dict:
    session["messages"].append({"role": "user", "content": prompt})
    result = chat(session["model_id"], session["messages"], max_tokens=max_tokens)
    session["messages"].append({"role": "assistant", "content": result["text"]})
    session["replies"].append({"prompt": prompt, "reply": result["text"],
                               "meta": result["meta"]})
    save_session(path, session)
    return result


def write_markdown(path: Path, session: dict) -> None:
    lines = [
        f"# {session['purpose']}",
        "",
        f"- Provider: {session['provider']}",
        f"- Displayed model: {session['display_name']}",
        f"- Model identifier: `{session['model_id']}`",
        f"- Access: {session['access']}",
        f"- Session opened (UTC): {session['date_utc']}",
        "- Transcript: visible user/assistant text only. Provider-side reasoning "
        "blocks are not displayed by the interface and are omitted.",
        "",
    ]
    turn = 0
    for message in session["messages"]:
        if message["role"] == "user":
            turn += 1
            lines += [f"## User prompt {turn}", "", "```text",
                      message["content"], "```", ""]
        else:
            lines += ["## Assistant reply", "", message["content"], ""]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
