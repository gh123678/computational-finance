"""Reproducible numerical checks for the four I1 claims.

Run: python code/check_i1_claims.py
Writes results/i1_checks.txt and results/i1_randomness.csv.
No AI output is used as input; every number is recomputed here.
"""
from __future__ import annotations

import csv
import math
from pathlib import Path

import numpy as np
from scipy.special import ndtr

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)
SEED = 20261021
rows: list[tuple[str, bool, str]] = []


def record(name: str, passed: bool, detail: str) -> None:
    rows.append((name, bool(passed), detail))


def bs_call(spot, strike, rate, vol, tau):
    d1 = (math.log(spot / strike) + (rate + 0.5 * vol**2) * tau) / (vol * math.sqrt(tau))
    d2 = d1 - vol * math.sqrt(tau)
    return spot * ndtr(d1) - strike * math.exp(-rate * tau) * ndtr(d2)


S0, mu, sigma, r, K, T = 100.0, 0.05, 0.20, 0.05, 105.0, 1.0

# ---------------------------------------------------------------- claim (a)
for c in (4.0,):
    e1 = S0 * math.exp(mu * T)
    v1 = S0**2 * math.exp(2 * mu * T) * (math.exp(sigma**2 * T) - 1)
    e2 = S0 * math.exp(mu * c * T)
    v2 = S0**2 * math.exp(2 * mu * c * T) * (math.exp(sigma**2 * c * T) - 1)
    record("(a) time-alone rescaling changes moments",
           abs(e1 - e2) > 1 and abs(v1 - v2) > 1,
           f"E: {e1:.6f} vs {e2:.6f}; Var: {v1:.3f} vs {v2:.3f} at c=4")
    # Brownian part is the self-similar object: W_{ct}/sqrt(c) has the law of W_t.
    rng = np.random.default_rng(SEED)
    n = 2_000_000
    z = rng.standard_normal(n)
    ratio_mean = (math.sqrt(c) * z).mean()
    ratio_var = (math.sqrt(c) * z).var(ddof=1)
    record("(a) Brownian part is 1/2-self-similar",
           abs(ratio_mean) < 0.01 and abs(ratio_var / c - 1.0) < 0.01,
           f"Var(sqrt(c)Z)/c = {ratio_var / c:.5f}")

# ---------------------------------------------------------------- claim (b)
mu_b, sig_b, T_b, L = 0.05, 0.30, 0.5, 100
h = T_b / L
a = 2 * mu_b + sig_b**2
per_step = math.exp(a * h) - 2 * math.exp(mu_b * h) + 1
finite_sum = L * per_step
limit = sig_b**2 * T_b
leading = (a**2 / 2 - mu_b**2) * T_b * h
record("(b) finite-grid simple-return sum is not sigma^2 T",
       abs(finite_sum - limit) > 1e-5,
       f"E[sum]={finite_sum:.9f}, sigma^2T={limit}, gap={finite_sum-limit:.3e}, "
       f"leading O(h)={leading:.3e}")
record("(b) finite-grid exact formula matches Taylor term",
       abs((finite_sum - limit) - leading) < 1e-6,
       f"exact gap {finite_sum-limit:.3e} vs leading {leading:.3e}")

M = 200_000
rng = np.random.default_rng(SEED + 1)
z = rng.standard_normal((M, L))
simple = np.expm1((mu_b - 0.5 * sig_b**2) * h + sig_b * math.sqrt(h) * z)
Q_simple = (simple**2).sum(axis=1)
euler = mu_b * h + sig_b * math.sqrt(h) * z
Q_euler = (euler**2).sum(axis=1)
se_simple = Q_simple.std(ddof=1) / math.sqrt(M)
record("(b) simulated sums are random with positive variance",
       Q_simple.var(ddof=1) > 0,
       f"mean={Q_simple.mean():.7f} SE={se_simple:.3e} "
       f"sd={Q_simple.std(ddof=1):.3e} min={Q_simple.min():.6f} max={Q_simple.max():.6f}")
record("(b) no simulated sum equals 0.045 exactly",
       not np.any(Q_simple == 0.045),
       f"closest distance={np.min(np.abs(Q_simple - 0.045)):.3e}")
euler_mean_gap = Q_euler.mean() - limit
euler_se = Q_euler.std(ddof=1) / math.sqrt(M)
record("(b) Euler mean sits above limit by about mu^2 T h",
       abs(euler_mean_gap - mu_b**2 * T_b * h) < 4 * euler_se,
       f"simulated gap={euler_mean_gap:.3e}, theory={mu_b**2*T_b*h:.3e}, "
       f"SE={euler_se:.3e}")

with (RESULTS / "i1_randomness.csv").open("w", newline="", encoding="utf-8") as fh:
    writer = csv.writer(fh)
    writer.writerow(["method", "path", "sum_squared_returns"])
    for i in range(1000):
        writer.writerow(["exact_simple", i, repr(float(Q_simple[i]))])
        writer.writerow(["euler", i, repr(float(Q_euler[i]))])

# ---------------------------------------------------------------- claim (c)
vol, tau = 0.20, 1.0
c_r = bs_call(S0, K, r, vol, tau)
c_mu = bs_call(S0, K, 0.12, vol, tau)  # artifact's physical drift, not equal to r
record("(c) physical drift changes the formula price",
       abs(c_r - c_mu) > 1e-3,
       f"price with r={c_r:.10f}, with mu={c_mu:.10f}")


def bs_call_derivs(spot, strike, rate, vol, tau):
    d1 = (math.log(spot / strike) + (rate + 0.5 * vol**2) * tau) / (vol * math.sqrt(tau))
    d2 = d1 - vol * math.sqrt(tau)
    price = spot * ndtr(d1) - strike * math.exp(-rate * tau) * ndtr(d2)
    delta = ndtr(d1)
    gamma = math.exp(-0.5 * d1**2) / (spot * vol * math.sqrt(2 * math.pi * tau))
    theta_calendar = (-spot * math.exp(-0.5 * d1**2) * vol / (2 * math.sqrt(2 * math.pi * tau))
                      - rate * strike * math.exp(-rate * tau) * ndtr(d2))
    return price, theta_calendar, delta, gamma


price, theta, delta, gamma = bs_call_derivs(S0, K, r, vol, tau)
residual = theta + 0.5 * vol**2 * S0**2 * gamma + r * S0 * delta - r * price
record("(c) the PDE itself contains no drift mu",
       abs(residual) < 1e-12,
       f"calendar-time residual = {residual:.3e}")

# ---------------------------------------------------------------- claim (d)
def residual(c, ct, cs, css, spot, t, rate=r, vol=vol):
    return ct + 0.5 * vol**2 * spot**2 * css + rate * spot * cs - rate * c


mismatches = []
for spot in (80.0, 100.0, 120.0):
    for t in (0.25, 0.75):
        # Model A pair: C = S, P = K exp(-r(T-t))
        rc = residual(spot, 0.0, 1.0, 0.0, spot, t)
        rp = residual(K * math.exp(-r * (T - t)), r * K * math.exp(-r * (T - t)),
                      0.0, 0.0, spot, t)
        mismatches.append(abs(rc) + abs(rp))
record("(d) Model A pair satisfies the interior PDE",
       max(mismatches) < 1e-12,
       f"max |residual| = {max(mismatches):.3e} over 6 points")
parity_a = (S0) - (K * math.exp(-r * T)) - (S0 - K * math.exp(-r * T))
record("(d) Model A pair satisfies parity",
       abs(parity_a) < 1e-12, f"residual = {parity_a:.3e}")
record("(d) Model A pair fails the terminal payoff",
       abs(S0 - max(S0 - K, 0.0)) > 1 and abs(K - max(K - S0, 0.0)) > 1,
       f"C(T,100)=100 vs payoff 0; P(T,100)=105 vs payoff 5")

# Model B pair: C = S, P = S - K exp(-r(T-t))
mismatches_b = []
for spot in (80.0, 100.0, 120.0):
    for t in (0.25, 0.75):
        rc = residual(spot, 0.0, 1.0, 0.0, spot, t)
        dt = -r * K * math.exp(-r * (T - t))
        rp = residual(spot - K * math.exp(-r * (T - t)), dt, 1.0, 0.0, spot, t)
        mismatches_b.append(abs(rc) + abs(rp))
record("(d) Model B pair satisfies the interior PDE",
       max(mismatches_b) < 1e-12,
       f"max |residual| = {max(mismatches_b):.3e} over 6 points")
parity_b = (S0 - (S0 - K * math.exp(-r * T))) - (S0 - K * math.exp(-r * T))
record("(d) Model B pair violates parity",
       abs(parity_b) > 1.0,
       f"left C-P={K*math.exp(-r*T):.6f}, required S-Ke^-rT={S0-K*math.exp(-r*T):.6f}, "
       f"residual={parity_b:.6f}")

passed = sum(1 for _, ok, _ in rows if ok)
lines = [f"I1 independent checks: {passed}/{len(rows)} passed"]
lines += [f"[{'PASS' if ok else 'FAIL'}] {name} :: {detail}" for name, ok, detail in rows]
text = "\n".join(lines) + "\n"
(RESULTS / "i1_checks.txt").write_text(text, encoding="utf-8")
print(text, end="")
