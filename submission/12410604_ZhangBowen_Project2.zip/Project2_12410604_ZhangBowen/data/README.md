# 数据快照与字段

`raw/fiz_daily.zip`、`raw/fiz_monthly.zip`是French 2024-12 FIZ官方档案；`raw/ciz_daily.zip`、`raw/ciz_monthly.zip`是2026-10-20取得的当前CIZ公开文件。数据当前内容截止范围见`results/data_coverage.csv`，获取UTC时刻与URL见`source_manifest.json`。所用主/后续窗口固定在`config.json`。

每份ZIP里的CSV第一数字区块包含`Mkt-RF, SMB, HML, RF`，原始单位为百分数。主入口只选择市场超额收益和RF，进入计算时除以100。日日期为YYYYMMDD，月日期YYYYMM。尾部年度汇总不作为月数据；`-99.99/-999`缺失标记拒绝处理。

这不是作者2015原始数据版本。研究因子也不是具体可买卖ETF的净值，包含的数据构造假设不能当作交易保证。

## 主要输出字段

| 字段 | 定义与单位 |
|---|---|
| `market_excess` | 官方月市场超额收益，小数 |
| `rf` | 官方月无风险收益，小数 |
| `rv` | 当月日超额收益去实际月均值后的偏差平方和，小数收益平方 |
| `daily_count` | 实际源数据交易日数，早期可能包含周六 |
| `lag_rv` | 上一自然月的rv，当前持有月使用 |
| `weight` | 扣费后财富中的风险资产目标比例，1=100% |
| `managed_excess` / `gross_excess` | 不扣本次扩展费用的w×market_excess |
| `pretrade_weight` | 月度持有后漂移至本次交易前的风险资产比例 |
| `one_way_turnover` | 单边实际成交额/交易前财富，包含首笔进场 |
| `fee_fraction` | 交易费/交易前财富 |
| `financing_fraction` | 额外借款利差/扣交易费后财富 |
| `total_return` | 含RF、交易成本和额外融资利差的月总收益 |
| `net_excess` | total_return - RF，月超额收益 |
| `nav` | 月末总收益净值，月前起始为1 |

所有绩效口径在协议中给出，`cagr_total`/`max_drawdown_total`使用含RF总收益，`sharpe`使用净超额收益。复现回归与原表对照报告百分数/年，CSV列名中`annual_pct`明确指该单位。

`sample_daily_for_manual_check.csv`提供4个形成月的全部日记录、实际均值和每一天的中心化平方，供显式手算；对应持有月见`results/manual_checks.csv`。
